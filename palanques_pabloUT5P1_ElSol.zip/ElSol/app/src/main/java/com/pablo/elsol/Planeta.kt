package com.pablo.elsol

data class Planeta (
    val nombre: String,
    val diametro: Double?,
    val distSol: Double,
    val densidad: Int
)