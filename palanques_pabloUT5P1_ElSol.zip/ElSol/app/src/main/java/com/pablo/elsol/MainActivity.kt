package com.pablo.elsol

import android.content.res.Configuration
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.NavigateNext
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.NavigateNext
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.pablo.elsol.ui.theme.ElSolTheme


//Variables para controlar orientación
var landscape = false
var pesoMenor = 0f
var pesoMayor = 0f

//Definimos algunas variables para un diseño consistente
val minSpacing = 4
val smallSpacing = 8
val mediumSpacing = 16
val largeSpacing = 44
val buttonWidth = 200
val titleTextSize = 44
val bigTextSize = 32
val medTextSize = 24


class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ElSolTheme {
                AppNavigation()
            }
        }
    }
}


//Esta función inserta Spacers del tamaño indicado
@Composable
fun InsertSpacer(n: Int) {
    Spacer(modifier = Modifier.size(n.dp))
}

//ORIENTACIÓN
@Composable
fun Orientacion() {
    val configuration = LocalConfiguration.current //variable que indica la orientación actual

    when (configuration.orientation) {
        Configuration.ORIENTATION_LANDSCAPE -> {
            landscape = true
            pesoMenor = 1f
            pesoMayor = 3f
        }
        else -> {
            landscape = false
            pesoMenor = 1f
            pesoMayor = 2f
        }
    }
}

//NAVEGACIÓN ENTRE PANTALLAS:
//Implementación de navegación entre pantallas añadiendo la siguiente dependencia:
//implementation("androidx.navigation:navigation-compose:2.8.0")
@Preview
@Composable
fun AppNavigation() {
    val navController = rememberNavController()
    NavHost(navController = navController, startDestination = "1-ElSol") {
        composable("1-ElSol") {
            elSol(navController)
        }
        composable("2-ElSol2") {
            elSol2(navController)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MyTopAppBar(navController: NavController) {
    //Estado para controlar si el menú está desplegado o no
    var menuExpanded by remember { mutableStateOf(false) }

    TopAppBar(
        //Título de la Topbar
        title = { Text(text="Sun images:", color = Color.Black) },
        //Icono de navegación, a la izquierda
//        navigationIcon = {
//            IconButton(onClick = {}) {
//                Icon(
//                    imageVector = Icons.Default.Menu,
//                    contentDescription = "Icono Menú",
//                    tint = Color.White
//                )
//            }
//        },
        //Iconos de acción, a la derecha
        actions = {
            //Botón de overflow
            //Al hacer clic desplegamos el menú
            IconButton(onClick = { menuExpanded = true }) {
                Icon(
                    imageVector = Icons.Default.MoreVert,
                    contentDescription = "Más opciones",
                    tint = Color.Black
                )
            }
            //Menú desplegable
            DropdownMenu(
                expanded = menuExpanded,
                onDismissRequest = { menuExpanded = false }
            ) {
                //Primera opción del menú
                DropdownMenuItem(
                    text = { Text("Next") },
                    onClick = {
                        menuExpanded = false
                        println("Siguiente pantalla")
                        navController.navigate(route = "2-ElSol2")
                    },
                    leadingIcon = {
                        Icon(Icons.AutoMirrored.Filled.NavigateNext, contentDescription = "Siguiente")
                    }
                )
            }
        },
        //Colores
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = Color.White,
            titleContentColor = Color.White,
            actionIconContentColor = Color.White
        )
    )
}