package com.pablo.elsol

import androidx.annotation.DrawableRes

data class Sol (
    @DrawableRes val imgId: Int,
    val name: String
)