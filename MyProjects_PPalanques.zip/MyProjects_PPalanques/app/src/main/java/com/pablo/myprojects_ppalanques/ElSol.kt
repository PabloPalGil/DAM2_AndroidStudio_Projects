package com.pablo.myprojects_ppalanques

import android.widget.Toast
import androidx.annotation.DrawableRes
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.lazy.staggeredgrid.LazyVerticalStaggeredGrid
import androidx.compose.foundation.lazy.staggeredgrid.StaggeredGridCells
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.NavigateNext
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.Card
import androidx.compose.material3.DrawerState
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.pablo.myprojects_ppalanques.ui.theme.Purple80
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch


@Composable
fun ElSol(navController: NavController) {
    val context = LocalContext.current

    //Para poder eliminar el Card que elijamos, trabajamos directamente con un mutableStateListOf:
    var listaCards = remember {
        mutableStateListOf(
            Sol(R.drawable.corona_solar, "Corona solar"),
            Sol(R.drawable.erupcionsolar, "Erupción solar"),
            Sol(R.drawable.espiculas, "Espiculas"),
            Sol(R.drawable.filamentos, "Filamentos"),
            Sol(R.drawable.magnetosfera, "Magnetosfera"),
            Sol(R.drawable.manchasolar, "Mancha solar")
        )
    }

    //Creamos las variables de estado del ModalDrawer (menú lateral):
    val mydrawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val corutina = rememberCoroutineScope()

    Scaffold(
        //Definimos nuestra topBar
        topBar = {
            SolTopAppBar(navController)//Definimos los parámetros de nuestra TopAppBar en una funcion aparte
        },
        //BottomAppBar (UT5-P1-Ej2):
        bottomBar = {
            //Como este proyecto ya tiene su propia BottomAppBar, decidimos mantenerla
            //en lugar de aplicar la de navegación entre proyectos (opcion comentada)
            SolBottomAppBar(mydrawerState)
            //MyBottomAppBar(navController)
        },
        content = { padding ->
            //Al utilizar Scaffold, el contenido central de la pantalla va entre estas llaves,
            //y le pasamos un padding para que no solape el contenido con la propia topBar

            //Añadimos el menú lateral (UT5-P1-Ej2):
            //Vemos que el menú lateral debe quedar por debajo de la BottomBar, por lo que
            //lo añadimos dentro de Scaffold, en este punto:
            SolModalDrawer(mydrawerState = mydrawerState, corutina,
                contenido = {
                    //Implementamos StaggeredGrid de los soles
                    LazyVerticalStaggeredGrid(
                        columns = StaggeredGridCells.Fixed(2),
                        modifier = Modifier
                            .padding(padding)
                            .padding(8.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalItemSpacing = 10.dp,
                        content = {
                            items(listaCards.size) { indice ->
                                val sol = listaCards[indice]
                                //Estado para controlar si el menú está desplegado o no
                                var menuExpanded by remember { mutableStateOf(false) }

                                Card(
                                    modifier = Modifier
                                        .fillMaxHeight()
                                        //Implementamos el toast al pulsar sobre Card
                                        .clickable {
                                            Toast
                                                .makeText(context, sol.name, Toast.LENGTH_SHORT)
                                                .show()
                                        }
                                ) {
                                    Column {
                                        Image(
                                            painter = painterResource(id = sol.imgId),
                                            contentDescription = "Imagen solar ${sol.name}",
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(250.dp),
                                            contentScale = ContentScale.FillHeight
                                        )
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(horizontal = 8.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text(
                                                text = sol.name,
                                                fontWeight = FontWeight.Bold,
                                                style = MaterialTheme.typography.bodyLarge
                                            )
                                            Box {
                                                IconButton(onClick = { menuExpanded = true }) {
                                                    Icon(
                                                        imageVector = Icons.Default.MoreVert,
                                                        contentDescription = "Sol item menu"
                                                    )
                                                }
                                                DropdownMenu(
                                                    expanded = menuExpanded,
                                                    onDismissRequest = { menuExpanded = false }
                                                ) {
                                                    DropdownMenuItem(
                                                        text = { Text("Copiar") },
                                                        onClick = {
                                                            menuExpanded = false
                                                            //Reto UT4-P3-Ej1
                                                            listaCards.add(sol)
                                                        },
                                                    )
                                                    DropdownMenuItem(
                                                        text = { Text("Eliminar") },
                                                        onClick = {
                                                            menuExpanded = false
                                                            //Reto UT4-P3-Ej1
                                                            listaCards.removeAt(indice)
                                                        }
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    )
                }
            )
        }
    )
}


//Funcion que define la BottomAppBar
//(desde el botón de flecha atrás se abre y cierra el Drawer)
@Composable
fun SolBottomAppBar(drawerState: DrawerState) {
    //Creamos una variable de estado para el número del badged del icono Favoritos
    var favoritos by remember { mutableIntStateOf(0) }

    //Creamos la variables de alcance del ModalDrawer (menú lateral):
    val corutina = rememberCoroutineScope()

    BottomAppBar(
        actions = {
            IconButton(
                onClick = {
                    corutina.launch {
                        drawerState.apply {
                            if (isClosed) open() else close()
                        }
                    }
                },
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Arrow Back"
                )
            }
            IconButton(
                onClick = {
                    //Incrementamos la cuenta del badged de favoritos
                    favoritos++
                },
                modifier = Modifier.width(50.dp)
            ) {
                BadgedBox(
                    badge = {
                        //Personalización del badge
                        Badge(
                            containerColor = Color(0xFF8D1400), //Color de fondo del badge
                            contentColor = Color.White, //Color del texto del badge
                        ) {
                            Text(
                                text = "$favoritos", //Texto del badge
                                style = TextStyle(fontSize = 10.sp) //Estilo del texto
                            )
                        }
                    }
                ) {
                    Icon(
                        imageVector = Icons.Filled.Favorite,
                        contentDescription = "Icono favoritos"
                    )
                }
            }
        },
        containerColor = Color.Red,
        contentColor = Color.White,
        //Añadimos el FAB dentro de la BottomBar:
        floatingActionButton = {
            MyFAB()
        }
    )
}

@Composable
fun MyFAB() {
    FloatingActionButton(
        onClick = { /*TODO*/ },
        containerColor = Purple80,
        contentColor = Color.Black
    ) {
        Icon(
            imageVector = Icons.Filled.Add,
            contentDescription = "Add"
        )
    }
}

//Función que implementa un menú lateral (ModalDrawer)
//entre las AppBar y el contenido de Scaffold
@Composable
fun SolModalDrawer(mydrawerState: DrawerState, corutina: CoroutineScope,
                  contenido: @Composable () -> Unit){

    //Definimos el ModalDrawer
    ModalNavigationDrawer(
        drawerState = mydrawerState,
        gesturesEnabled = false,
        drawerContent = {
            ModalDrawerSheet(drawerTonalElevation = 100.dp) {
                //Definimos la cabecera del menú
                NavBarHeader()
                //Primera opción del menú
                NavigationDrawerItem(
                    label = { Text("Build") },
                    selected = false,
                    modifier = Modifier.padding(8.dp),
                    onClick = { },
                    icon = { Icon(Icons.Filled.Build, contentDescription = "Build icon") }
                )
                //Segunda opción del menú
                NavigationDrawerItem(
                    label = { Text("Info") },
                    selected = false,
                    modifier = Modifier.padding(8.dp),
                    onClick = { },
                    icon = { Icon(Icons.Filled.Info, contentDescription = "Info icon") }
                )
                //Tercera opción del menú
                NavigationDrawerItem(
                    label = { Text("Email") },
                    selected = false,
                    modifier = Modifier.padding(8.dp),
                    onClick = { },
                    icon = { Icon(Icons.Filled.Email, contentDescription = "Email icon") }
                )
            }
        }
    ) {
        //En contenido se implementa el cuerpo de Scaffold de esta pantalla,
        //el código del mismo se define en la llamada a esta funcion MyModalDrawer
        contenido()
    }
}

//Función que crea una cabecera para el menú lateral
@Composable
fun NavBarHeader() {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .wrapContentHeight(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Image(
            painter = painterResource(id = R.drawable.sol1),
            contentDescription = "Cabecera El Sol",
            contentScale = ContentScale.FillWidth,
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 56.dp)
        )
    }
}


data class Planeta (
    val nombre: String,
    val diametro: Double?,
    val distSol: Double,
    val densidad: Int
)

data class Sol (
    @DrawableRes val imgId: Int,
    val name: String
)



@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SolTopAppBar(navController: NavController) {
    //Estado para controlar si el menú está desplegado o no
    var menuExpanded by remember { mutableStateOf(false) }

    TopAppBar(
        //Título de la Topbar
        title = { Text(text="Sun images:", color = Color.Black) },
        //Iconos de acción, a la derecha
        actions = {
            //Botón de overflow
            //Al hacer clic desplegamos el menú
            IconButton(onClick = { menuExpanded = true }) {
                Icon(
                    imageVector = Icons.Default.MoreVert,
                    contentDescription = "Más opciones",
                    tint = Color.Black
                )
            }
            //Menú desplegable
            DropdownMenu(
                expanded = menuExpanded,
                onDismissRequest = { menuExpanded = false }
            ) {
                //Primera opción del menú
                DropdownMenuItem(
                    text = { Text("Next") },
                    onClick = {
                        menuExpanded = false
                        println("Siguiente pantalla")
                        navController.navigate(route = "5-ElSol2")
                    },
                    leadingIcon = {
                        Icon(Icons.AutoMirrored.Filled.NavigateNext, contentDescription = "Siguiente")
                    }
                )
            }
        },
        //Colores
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = Color.White,
            titleContentColor = Color.White,
            actionIconContentColor = Color.White
        )
    )
}