package com.pablo.myprojects_ppalanques

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.pablo.myprojects_ppalanques.ui.theme.Purple40
import com.pablo.myprojects_ppalanques.ui.theme.PurpleSoft
import com.pablo.myprojects_ppalanques.ui.theme.PurpleStrong


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ElSol2(navController: NavController) {
    //Recabamos los datos de los planetas
    val planetas = getPlanetas()

    //Variables de estado de los 2 TextField:
    var planeta1 by rememberSaveable { mutableStateOf("") }
    var planeta2 by rememberSaveable { mutableStateOf("") }

    //Variables de estado de todos los textos:
    var diam1 by rememberSaveable { mutableStateOf("") }
    var diam2 by rememberSaveable { mutableStateOf("") }
    var distSol1 by rememberSaveable { mutableStateOf("") }
    var distSol2 by rememberSaveable { mutableStateOf("") }
    var dens1 by rememberSaveable { mutableStateOf("") }
    var dens2 by rememberSaveable { mutableStateOf("") }

    //Función que autocompleta todos los TextField a partir del planeta 1 elegido:
    fun autoFillPlanet1(p: Planeta) {
        if (p.diametro == null)
            diam1 = "???"
        else
            diam1 = p.diametro.toString()
        distSol1 = p.distSol.toString()
        dens1 = p.densidad.toString()
    }

    //Lista de sugerencias
    val opciones = planetas

    // Estado para mostrar el menú desplegable
    var expandedMenu1 by rememberSaveable { mutableStateOf(false) }
    var expandedMenu2 by rememberSaveable { mutableStateOf(false) }

    // Filtrar las opciones según el texto ingresado1
//    val sugerenciasFiltradas1 = opciones.filter { it.nombre.contains(planeta1.trim(), ignoreCase = true) }
    val sugerenciasFiltradas1 = remember(planeta1) {
        opciones.filter {
            it.nombre.contains(
                planeta1.trim(),
                ignoreCase = true
            )
        }
    }

    // Filtrar las opciones según el texto ingresado2
    val sugerenciasFiltradas2 =
        opciones.filter { it.nombre.contains(planeta2.trim(), ignoreCase = true) }

    //Función que autocompleta todos los TextField a partir del planeta 2 elegido:
    fun autoFillPlanet2(p: Planeta) {
        if (p.diametro == null)
            diam2 = "???"
        else
            diam2 = p.diametro.toString()
        distSol2 = p.distSol.toString()
        dens2 = p.densidad.toString()
    }

    //Creamos las variables de estado del ModalDrawer (menú lateral):
    val mydrawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val corutina = rememberCoroutineScope()

    //Para introducir la TopAppBar utilizamos el layout Scaffold (típico de la UI de android):
    Scaffold(
        //Definimos nuestra topBar
        topBar = {
            TopAppBar(
                //Título de la Topbar
                title = { Text(text = "El Sol", color = Color.White) },
                //Colores
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.onSurface,
                    titleContentColor = Color.White,
                    actionIconContentColor = Color.White
                )
            )
        },
        //BottomAppBar (UT5-P1-Ej2):
        bottomBar = {
            //Como este proyecto ya tiene su propia BottomAppBar, decidimos mantenerla
            //en lugar de aplicar la de navegación entre proyectos (opcion comentada)
            SolBottomAppBar(mydrawerState)
            //MyBottomAppBar(navController)
        },
        containerColor = Color.White,
        content = { padding ->
            //Al utilizar Scaffold, el contenido central de la pantalla va entre estas llaves,
            //y le pasamos un padding para que no solape el contenido con la propia topBar

            //Añadimos el menú lateral (UT5-P1-Ej2):
            //Vemos que el menú lateral debe quedar por debajo de la BottomBar, por lo que
            //lo añadimos dentro de Scaffold, en este punto:
            SolModalDrawer(
                mydrawerState = mydrawerState, corutina,
                contenido = {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(padding)
                            .padding(8.dp),
                        verticalArrangement = Arrangement.Top,
                    ) {
                        //Usamos Rows para poder alinear los componentes horizontalmente
                        Row(
                            horizontalArrangement = Arrangement.Start,
                            modifier = Modifier.padding(8.dp)
                        ) {
                            Text(
                                text = "Compara planetas",
                                color = Color.Black,
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.bodyLarge
                            )
                        }

                        InsertSpacer(n = 4)

                        Row(
                            modifier = Modifier
                                .fillMaxWidth(),
                            horizontalArrangement = Arrangement.Center
                        ) {

                            //Colocamos los ExposedDropDownMenuBox en sendas columnas
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(end = 4.dp)
                                    .weight(1f),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                //ExposedDropDownMenuBox que contendrá el TextField y el ExposedDropDownMenu
                                ExposedDropdownMenuBox(
                                    expanded = expandedMenu1,
                                    onExpandedChange = { expandedMenu1 = !expandedMenu1 },
                                ) {
                                    TextField(
                                        modifier = Modifier
                                            .menuAnchor()
                                            .padding(1.dp)
                                            .background(PurpleStrong),
                                        readOnly = false,
                                        value = planeta1,
                                        onValueChange = { newText ->  // "newText" es el String escrito por el usuario
                                            planeta1 =
                                                newText  // Actualizamos el estado con el nuevo valor
                                            expandedMenu1 = newText.isNotEmpty()
                                        },
                                        shape = RectangleShape,
                                        colors = ExposedDropdownMenuDefaults.textFieldColors(
                                            unfocusedContainerColor = PurpleStrong,
                                            focusedContainerColor = PurpleStrong,
                                            unfocusedTextColor = Color.Black,
                                            focusedTextColor = Color.Black
                                        ),
                                    )
                                    ExposedDropdownMenu(
                                        expanded = expandedMenu1,
                                        onDismissRequest = { expandedMenu1 = false },
                                        modifier = Modifier.background(Color.White)
                                    ) {
                                        sugerenciasFiltradas1.forEach { selectionOption ->
                                            DropdownMenuItem(
                                                text = {
                                                    Text(
                                                        selectionOption.nombre,
                                                        color = Color.Black
                                                    )
                                                },
                                                onClick = {
                                                    planeta1 = selectionOption.nombre
                                                    expandedMenu1 = false
                                                    autoFillPlanet1(selectionOption)
                                                },
                                                contentPadding =
                                                ExposedDropdownMenuDefaults.ItemContentPadding,
                                            )
                                        }
                                    }
                                }
                            }

                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(end = 4.dp)
                                    .weight(1f),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                //ExposedDropDownMenuBox que contendrá el TextField y el ExposedDropDownMenu
                                ExposedDropdownMenuBox(
                                    expanded = expandedMenu2,
                                    onExpandedChange = { expandedMenu2 = !expandedMenu2 },
                                ) {
                                    TextField(
                                        modifier = Modifier
                                            .menuAnchor()
                                            .padding(1.dp)
                                            .background(PurpleStrong),
                                        readOnly = false,
                                        value = planeta2,
                                        onValueChange = { newText ->  // "newText" es el String escrito por el usuario
                                            planeta2 =
                                                newText  // Actualizamos el estado con el nuevo valor
                                            expandedMenu2 = newText.isNotEmpty()
                                        },
                                        shape = RectangleShape,
                                        colors = ExposedDropdownMenuDefaults.textFieldColors(
                                            unfocusedContainerColor = PurpleStrong,
                                            focusedContainerColor = PurpleStrong,
                                            unfocusedTextColor = Color.Black,
                                            focusedTextColor = Color.Black
                                        ),
                                    )
                                    ExposedDropdownMenu(
                                        expanded = expandedMenu2,
                                        onDismissRequest = { expandedMenu2 = false },
                                    ) {
                                        sugerenciasFiltradas2.forEach { selectionOption ->
                                            DropdownMenuItem(
                                                text = { Text(selectionOption.nombre) },
                                                onClick = {
                                                    planeta2 = selectionOption.nombre
                                                    expandedMenu2 = false
                                                    autoFillPlanet2(selectionOption)
                                                },
                                                contentPadding =
                                                ExposedDropdownMenuDefaults.ItemContentPadding,
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        InsertSpacer(n = 16)

                        //Etiqueta Diámetros
                        Row(
                            horizontalArrangement = Arrangement.Center,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "Diámetro",
                                color = PurpleStrong,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        //Valores de diámetro de cada planeta
                        Row(
                            modifier = Modifier
                                .padding(8.dp)
                                .fillMaxWidth()
                                .background(PurpleSoft),
                            horizontalArrangement = Arrangement.SpaceEvenly
                        ) {
                            Column(
                                modifier = Modifier.weight(1f),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = diam1,
                                    color = Purple40,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Column(
                                modifier = Modifier.weight(1f),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = diam2,
                                    color = Purple40,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        //Etiqueta Distancia al Sol
                        Row(
                            horizontalArrangement = Arrangement.Center,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "Distancia al Sol",
                                color = PurpleStrong,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        //Valores de distancia al sol de cada planeta
                        Row(
                            modifier = Modifier
                                .padding(8.dp)
                                .fillMaxWidth()
                                .background(PurpleSoft),
                            horizontalArrangement = Arrangement.SpaceEvenly
                        ) {
                            Column(
                                modifier = Modifier.weight(1f),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = distSol1,
                                    color = Purple40,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Column(
                                modifier = Modifier.weight(1f),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = distSol2,
                                    color = Purple40,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        //Etiqueta Densidad
                        Row(
                            horizontalArrangement = Arrangement.Center,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "Densidad",
                                color = PurpleStrong,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        //Valores de diámetro de cada planeta
                        Row(
                            modifier = Modifier
                                .padding(8.dp)
                                .fillMaxWidth()
                                .background(PurpleSoft),
                            horizontalArrangement = Arrangement.SpaceEvenly
                        ) {
                            Column(
                                modifier = Modifier.weight(1f),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = dens1,
                                    color = Purple40,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Column(
                                modifier = Modifier.weight(1f),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = dens2,
                                    color = Purple40,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            )
        }
    )
}


fun getPlanetas(): List<Planeta> {
    return listOf(
        Planeta("Mercurio", 0.382, 0.387, 5400),
        Planeta("Venus", 0.949, 0.723, 5250),
        Planeta("Tierra", 1.0, 1.0, 5520),
        Planeta("Marte", 0.53, 1.542, 3960),
        Planeta("Júpiter", 11.2, 5.203, 1350),
        Planeta("Saturno", 9.41, 9.539, 700),
        Planeta("Urano", 3.38, 19.81, 1200),
        Planeta("Neptuno", 3.81, 30.07, 500),
        Planeta("Plutón", null, 39.44, 5)
    )
}