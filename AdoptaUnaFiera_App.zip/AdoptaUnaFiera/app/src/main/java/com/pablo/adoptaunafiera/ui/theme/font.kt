package com.pablo.adoptaunafiera.ui.theme

import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import com.pablo.adoptaunafiera.R


// Tipografía personalizada para la fuente externa
val courgetteFont = FontFamily(
    Font(R.font.courgette_regular, FontWeight.Normal)
)

//Helvetica
val helveticaFont = FontFamily(
    Font(R.font.helvetica, FontWeight.Normal),
    Font(R.font.helvetica_bold, FontWeight.Bold),
)

//Lucida-Sans
val lucidaSansFont = FontFamily(
    Font(R.font.lucida_sans, FontWeight.Normal),
    Font(R.font.lucida_sans_bold, FontWeight.Bold),
)