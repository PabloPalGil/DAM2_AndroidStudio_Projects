package com.pablo.adoptaunafiera

import android.content.res.Configuration
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.pablo.adoptaunafiera.ui.theme.AdoptaUnaFieraTheme
import kotlinx.coroutines.delay
import java.time.LocalDate


//Variables para controlar orientación
var landscape = false
var pesoMenor = 0f
var pesoMayor = 0f

//Creamos la variable gatos al iniciar la app
// (todo: implementar persistencia de datos entre sesiones)
var gatos = inicializaGatos()

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AdoptaUnaFieraTheme {
                AppNavigation()
            }
        }
    }
}


//Esta función inserta Spacers del tamaño indicado
@Composable
fun InsertSpacer(n: Int) {
    Spacer(modifier = Modifier.size(n.dp))
}

//ORIENTACIÓN
@Composable
fun orientacion() {
    val configuration = LocalConfiguration.current //variable que indica la orientación actual

    when (configuration.orientation) {
        Configuration.ORIENTATION_LANDSCAPE -> {
            landscape = true
            pesoMenor = 1f
            pesoMayor = 3f
        }
        else -> {
            landscape = false
            pesoMenor = 1f
            pesoMayor = 2f
        }
    }
}

//NAVEGACIÓN ENTRE PANTALLAS:
//Implementación de navegación entre pantallas añadiendo la siguiente dependencia:
//implementation("androidx.navigation:navigation-compose:2.8.0")
@Preview
@Composable
fun AppNavigation() {
    val navController = rememberNavController()
    NavHost(navController = navController, startDestination = "1-MenuPrincipal") {
        composable("1-MenuPrincipal") {
            menuPrincipal(navController)
        }
        composable("2-VerGatitos") {
            verGatitos(navController)
        }
        composable("3-QuieroAdoptar") {
            quieroAdoptar(navController)
        }
        composable("4-Conocenos") {
            conocenos(navController)
        }
    }
}


//Funcion para tener unos datos de entrada con los que trabajar
fun inicializaGatos() : Gatos {
    //Definimos los gatos uno a uno:
    val gato1 = Gato("Mew", Genero.HEMBRA, Estado.DISPONIBLE,
        LocalDate.of(2024, 6, 27), Raza.COMUN,
        "https://cdn.pixabay.com/photo/2019/10/18/09/29/cat-4558651_1280.jpg")

    val gato2 = Gato("Persian", Genero.MACHO, Estado.RESERVADO,
        LocalDate.of(2024, 8, 17), Raza.PERSA,
        "https://cdn.pixabay.com/photo/2017/11/15/05/57/cat-2950943_1280.jpg")

    val gato3 = Gato("Roco", Genero.HEMBRA, Estado.DISPONIBLE,
        LocalDate.of(2024, 8, 2), Raza.BENGALI,
        "https://cdn.pixabay.com/photo/2021/10/27/19/09/cat-6748193_1280.jpg")

    val gato4 = Gato("Lyndy", Genero.MACHO, Estado.RESERVADO,
        LocalDate.of(2024, 7, 10), Raza.SIBERIANO,
        "https://gatitosiberiano.eu/wp-content/uploads/2023/01/Jessi-1-738x1024.jpg")

    val gato5 = Gato("Mozzarella", Genero.HEMBRA, Estado.RESERVADO,
        LocalDate.of(2024, 6, 22), Raza.COMUN,
        "https://cdn.pixabay.com/photo/2023/10/15/16/06/the-cat-8317334_1280.jpg")

    val gato6 = Gato("Bigotes", Genero.MACHO, Estado.DISPONIBLE,
        LocalDate.of(2024, 8, 7), Raza.PERSA,
        "https://cdn.pixabay.com/photo/2015/07/04/12/30/cat-831258_1280.jpg")

    val gato7 = Gato("Mitsuki", Genero.HEMBRA, Estado.DISPONIBLE,
        LocalDate.of(2024, 9, 5), Raza.BENGALI,
        "https://cdn.pixabay.com/photo/2023/05/27/22/56/kitten-8022452_1280.jpg")

    val gato8 = Gato("Suavito", Genero.MACHO, Estado.DISPONIBLE,
        LocalDate.of(2024, 7, 10), Raza.SIBERIANO,
        "https://gatitosiberiano.eu/wp-content/uploads/2023/01/Jessi-5-768x522.jpg")



    gatos = Gatos(mutableListOf(gato1, gato2, gato3, gato4, gato5, gato6, gato7, gato8))
    return gatos
}
