package com.pablo.adoptaunafiera

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults.buttonColors
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldColors
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.pablo.adoptaunafiera.ui.theme.courgetteFont
import com.pablo.adoptaunafiera.ui.theme.helveticaFont
import com.pablo.adoptaunafiera.ui.theme.lucidaSansFont


val smallPadding = 16


//CON NAVEGACIÓN:
@Composable
fun quieroAdoptar(navController: NavController){

    //TextFields
    //Definimos las variables necesarias para los TextField
    var textName by rememberSaveable { mutableStateOf("") }
    var textSurname by rememberSaveable { mutableStateOf("") }
    var textPhone by rememberSaveable { mutableStateOf("") }
    var textEmail by rememberSaveable { mutableStateOf("") }
    var textCat by rememberSaveable { mutableStateOf("") }

    //Estados para almacenar los errores de los TextField
    var fieldNameError by rememberSaveable { mutableStateOf(false) }
    var fieldSurnameError by rememberSaveable { mutableStateOf(false) }
    var fieldEmailError by rememberSaveable { mutableStateOf(false) }


    //RadioButton
    //Variable para gestionar el estado del radio button seleccionado
    var estadoRadio by rememberSaveable { mutableStateOf("") }

    //Creamos las opciones de los radio buttons:
    val generos = listOf("Macho", "Hembra", "Indiferente")


    //CheckBoxes
    //Variables de estado de los checkBoxes
    var isChecked1 by rememberSaveable { mutableStateOf(false) }
    var isChecked2 by rememberSaveable { mutableStateOf(false) }
    var isChecked3 by rememberSaveable { mutableStateOf(false) }
    var isChecked4 by rememberSaveable { mutableStateOf(false) }


    //TextField grande
    //Definimos la variable de estado del TextField de las razones de adopción
    var textReasons by rememberSaveable { mutableStateOf("") }


    //Métodos:
    //Funcion que comprueba que se han rellenado los TextField Nombre, Apellidos y Email
    fun checkTextFields() {
        fieldNameError = textName.isEmpty()
        fieldSurnameError = textName.isEmpty()
        fieldEmailError = textEmail.isEmpty()
    }


    @Composable
    fun RepaintTextField(fieldIsError: Boolean) : TextFieldColors {
        //Si está en error, el fondo será rojo:
        if(fieldIsError) {
            return TextFieldDefaults.colors(errorContainerColor = MaterialTheme.colorScheme.errorContainer)
        } else {
            return TextFieldDefaults.colors(
                unfocusedContainerColor = MaterialTheme.colorScheme.primary,
                focusedIndicatorColor = MaterialTheme.colorScheme.secondary
            )
        }
    }

    orientacion()//Comprobamos la orientación

    Column( //Vamos a organizar el layout por filas
        Modifier
            .fillMaxSize()
            .padding(smallPadding.dp)
            .verticalScroll(rememberScrollState()), //Con posibilidad de hacer scroll
        horizontalAlignment = Alignment.CenterHorizontally, //Contenido centrado horizontalmente
        verticalArrangement = Arrangement.Top) { //Organizando las filas desde la parte superior

        //Título de la pantalla
        Text(text = "Formulario de contacto", fontSize = 24.sp,
            fontFamily = helveticaFont
        )

        InsertSpacer(largeSpacing)//Espacio entre el título y los botones

        //Organizamos cada fila en columnas
        Row(Modifier.fillMaxSize()){
            //El primer elemento es un icono:
            Image(painter = painterResource(id = R.drawable.icon_person),
                contentDescription = "Nombre",
                modifier = Modifier
                    .weight(pesoMenor)
                    .size(60.dp))

            //El segundo elemento es un campo de texto
            TextField(
                value = textName,  // El valor actual del campo de texto
                onValueChange = { newText ->  // "newText" es el String escrito por el usuario
                    textName = newText  // Actualizamos el estado con el nuevo valor
                },
                label = { Text("Nombre") }, // Etiqueta
                placeholder = {Text("Tu nombre...")},//Pista que aparece cuando está en blanco
                modifier = Modifier
                    .weight(pesoMayor) //Ajustamos el tamaño del TextField
                    .padding(10.dp),
                colors = RepaintTextField(fieldNameError), //Función que pinta el TextField rojo si es inválido
                shape = RoundedCornerShape(
                    topStart = 15.dp,
                    topEnd = 15.dp
                ),
                isError = fieldNameError //Si da error, resaltar el error
            )
        }
        //Ponemos un Text justo debajo del Field obligatorio
        if (fieldNameError) {
            Text(
                text = "Error: Obligatorio",
                color = MaterialTheme.colorScheme.error,
                modifier = Modifier
                    .padding(bottom = 8.dp)
            )
        } else {
            Text(
                text = "*Obligatorio",
                color = MaterialTheme.colorScheme.secondary,
                modifier = Modifier.padding(bottom = 8.dp)
            )
        }

        InsertSpacer(n = smallPadding)//Separación entre filas

        Row(Modifier.fillMaxSize()){
            //Dejamos el hueco del primer elemento porque no hay icono:
            Spacer(Modifier.weight(pesoMenor))

            //El segundo elemento es un campo de texto
            TextField(
                value = textSurname,  // El valor actual del campo de texto
                onValueChange = { newText ->  // "newText" es el String escrito por el usuario
                    textSurname = newText  // Actualizamos el estado con el nuevo valor
                },
                label = { Text("Apellidos") }, // Etiqueta
                placeholder = {Text("Tus apellidos...")},//Pista que aparece cuando está en blanco
                modifier = Modifier
                    .weight(pesoMayor)
                    .padding(10.dp),
                colors = RepaintTextField(fieldSurnameError), //Función que pinta el TextField de forma personalizada,
                shape = RoundedCornerShape(
                    topStart = 15.dp,
                    topEnd = 15.dp
                ),
                isError = fieldSurnameError //Si da error, resaltar el error
            )
        }
        //Ponemos un Text justo debajo del Field obligatorio
        if (fieldSurnameError) {
            Text(
                text = "Error: Obligatorio",
                color = MaterialTheme.colorScheme.error,
                modifier = Modifier
                    .padding(bottom = 8.dp)
            )
        } else {
            Text(
                text = "*Obligatorio",
                color = MaterialTheme.colorScheme.secondary,
                modifier = Modifier.padding(bottom = 8.dp)
            )
        }

        InsertSpacer(n = smallPadding)//Separación entre filas

        Row(Modifier.fillMaxSize()){
            //El primer elemento es un icono:
            Image(painter = painterResource(id = R.drawable.icon_phone),
                contentDescription = "Phone",
                modifier = Modifier
                    .weight(pesoMenor)
                    .size(60.dp))

            //El segundo elemento es un campo de texto
            TextField(
                value = textPhone,  // El valor actual del campo de texto
                onValueChange = { newText ->  // "newText" es el String escrito por el usuario
                    textPhone = newText  // Actualizamos el estado con el nuevo valor
                },
                label = { Text("Teléfono") }, // Etiqueta
                placeholder = {Text("+34-611001122")},//Pista que aparece cuando está en blanco
                modifier = Modifier
                    .weight(pesoMayor) // Ajustamos el tamaño del TextField
                    .padding(10.dp),
                colors = RepaintTextField(false), //Función que pinta el TextField rojo si es inválido
                shape = RoundedCornerShape(
                    topStart = 15.dp,
                    topEnd = 15.dp
                )
            )
        }

        InsertSpacer(n = smallPadding)//Separación entre filas

        Row(Modifier.fillMaxSize()){
            //El primer elemento es un icono:
            Image(painter = painterResource(id = R.drawable.icon_email),
                contentDescription = "Email",
                modifier = Modifier
                    .weight(pesoMenor)
                    .size(60.dp))

            //El segundo elemento es un campo de texto
            TextField(
                value = textEmail,  // El valor actual del campo de texto
                onValueChange = { newText ->  // "newText" es el String escrito por el usuario
                    textEmail = newText  // Actualizamos el estado con el nuevo valor
                },
                label = { Text("Email") }, // Etiqueta
                placeholder = {Text("algo@gmail.com")},//Pista que aparece cuando está en blanco
                modifier = Modifier
                    .weight(pesoMayor) // Ajustamos el tamaño del TextField
                    .padding(10.dp),
                colors = RepaintTextField(fieldEmailError), //Función que pinta el TextField de forma personalizada,
                shape = RoundedCornerShape(
                    topStart = 15.dp,
                    topEnd = 15.dp
                ),
                isError = fieldEmailError //Si da error, resaltar el error
            )
        }
        //Ponemos un Text justo debajo del Field obligatorio
        if (fieldSurnameError) {
            Text(
                text = "Error: Obligatorio",
                color = MaterialTheme.colorScheme.error,
                modifier = Modifier
                    .padding(bottom = 8.dp)
            )
        } else {
            Text(
                text = "*Obligatorio",
                color = MaterialTheme.colorScheme.secondary,
                modifier = Modifier.padding(bottom = 8.dp)
            )
        }

        InsertSpacer(n = smallPadding)//Separación entre filas

        Row(Modifier.fillMaxSize()) {
            Button(onClick = { navController.navigate(route = "2-VerGatitos") },
                Modifier.width(buttonWidth.dp)
                    .weight(pesoMenor),
                shape = RoundedCornerShape(size = 15.dp)
            ) {
                Text(text = "Ver gatitos")
            }
//            Text(text = "", modifier = Modifier.weight(pesoMenor))
            //Campo de texto para indicar el nombre del gato a adoptar, si ya se sabe:
            Text(text = "Si ya sabes qué gatito quieres, indícalo a continuación:",
                modifier = Modifier.fillMaxWidth()
                    .weight(pesoMayor)
                    .padding(10.dp),
                textAlign = TextAlign.Start)
        }

        Row(Modifier.fillMaxSize()){
            //El primer elemento es un icono:
            Image(painter = painterResource(id = R.drawable.icon_cat),
                contentDescription = "Gatito",
                modifier = Modifier
                    .weight(pesoMenor)
                    .size(60.dp))

            //El segundo elemento es un campo de texto
            TextField(
                value = textCat,  // El valor actual del campo de texto
                onValueChange = { newText ->  // "newText" es el String escrito por el usuario
                    textCat = newText  // Actualizamos el estado con el nuevo valor
                },
                label = { Text("Gato") }, // Etiqueta
                placeholder = {Text("Nombre del gatito...")},//Pista que aparece cuando está en blanco
                modifier = Modifier
                    .weight(pesoMayor) // Ajustamos el tamaño del TextField
                    .padding(10.dp),
                colors = RepaintTextField(false), //Función que pinta el TextField rojo si es inválido
                shape = RoundedCornerShape(
                    topStart = 15.dp,
                    topEnd = 15.dp
                )
            )
        }

        InsertSpacer(n = mediumSpacing)//Separación

        //Preguntamos mediante radioButtons por la preferencia del género del animal
        //Solicitamos la selección
        Text(text = "¿Tienes alguna preferencia en cuanto al género del gatito?",
            fontSize = 24.sp,
            modifier = Modifier
                .fillMaxWidth(0.75f)
                .padding(bottom = minSpacing.dp)
        )
        //Vamos colocando los radio buttons en rows con su respectiva etiqueta:
        generos.forEach { item ->
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Start,
                modifier = Modifier
                    .padding(8.dp)
                    .fillMaxWidth(0.75f)
            ) {
                //Colocamos el radioButton
                RadioButton(selected = estadoRadio == item, onClick = {
                    estadoRadio = item
                })
                //Colocamos el Text del RadioButton
                Text(text = item,
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.Start)
            }
        }

        InsertSpacer(n = mediumSpacing)//Separación entre filas

        //Solicitamos la selección
        Text(text = "¿En cuáles de nuestras razas estás interesado?",
            fontSize = 24.sp,
            modifier = Modifier
                .fillMaxWidth(0.75f)
                .padding(bottom = minSpacing.dp)
        )

        //Añadir checkBoxes para indicar las razas de interés en un Row para que salga el texto al lado:
        Row(
            modifier = Modifier.fillMaxWidth(0.75f),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Start
        ) {
            Checkbox(
                checked = isChecked1,
                onCheckedChange = { isChecked1 = it })

            Text(text = "Común")
        }

        InsertSpacer(n = smallPadding)

        Row(
            modifier = Modifier.fillMaxWidth(0.75f),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Start
        ) {
            Checkbox(
                checked = isChecked2,
                onCheckedChange = { isChecked2 = it })

            Text(text = "Persa")
        }

        InsertSpacer(n = smallPadding)

        Row(
            modifier = Modifier.fillMaxWidth(0.75f),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Start
        ) {
            Checkbox(
                checked = isChecked3,
                onCheckedChange = { isChecked3 = it })

            Text(text = "Bengalí")
        }

        InsertSpacer(n = smallPadding)

        Row(
            modifier = Modifier.fillMaxWidth(0.75f),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Start
        ) {
            Checkbox(
                checked = isChecked4,
                onCheckedChange = { isChecked4 = it })

            Text(text = "Siberiano")
        }

        InsertSpacer(n = mediumSpacing)//Separación entre filas

        //Solicitamos la selección
        Text(text = "Por favor, escribe brevemente por qué quieres adoptar un gatito:",
            fontSize = 24.sp,
            modifier = Modifier
                .fillMaxWidth(0.9f)
                .padding(smallPadding.dp)
        )

        //TextField para indicar las razones para adoptar un gatito:
        TextField(
            value = textReasons,  //El valor actual del campo de texto
            onValueChange = { textReasons = it },  //Actualizamos el estado con el nuevo valor
            modifier = Modifier
                .fillMaxWidth(0.9f) //Ajustamos el tamaño del TextField
                .height(200.dp)
                .padding(smallPadding.dp)
        )

        InsertSpacer(n = mediumSpacing)//Separación entre filas

        Button(
            onClick = { checkTextFields() },
            modifier = Modifier.fillMaxWidth(0.75f),
            shape = RoundedCornerShape(size = 15.dp)
        ) {
            Text(text = "Enviar formulario", modifier = Modifier.padding(5.dp))
        }

        InsertSpacer(n = smallPadding)//Separación entre filas

        Button(
            onClick = { navController.navigate(route = "1-MenuPrincipal") },
            modifier = Modifier.width(buttonWidth.dp),
            shape = RoundedCornerShape(size = 15.dp)
        ) {
            Text(text = "Cancelar y volver")
        }
    }
}
