package com.pablo.adoptaunafiera

enum class Raza {
    COMUN,
    SIBERIANO,
    PERSA,
    BENGALI
}