package com.pablo.adoptaunafiera

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.pablo.adoptaunafiera.ui.theme.courgetteFont

@Composable
fun conocenos(navController: NavController) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()), //Con posibilidad de hacer scroll
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        //Título
        Text(
            text = "Bienvenidos a \"Adopta una Fiera\"",
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.padding(mediumSpacing.dp),
            fontFamily = courgetteFont
        )

        //Añadimos la imagen principal de internet (Creative Commons 0):
        AsyncImage(
            model = ImageRequest.Builder(LocalContext.current)
                .data("https://c.pxhere.com/photos/4d/64/kittens_cat_cat_puppy_rush_free_float_kitten_lucky_cat_cat_breeding-918620.jpg!d")
                .build(),
            contentDescription = "Bienvenido a nuestro criadero de gatitos",
            //Forzamos la imagen a ocupar los límites, mantiendo la rel. de aspecto
            contentScale = ContentScale.Fit,
        )

        InsertSpacer(n = smallPadding)

        //Texto principal sobre el criadero
        Text(
            text =
            "\"Adopta Una Fiera\" es un criadero de gatitos dedicado a criar gatos con amor y responsabilidad.\n" +
                    "Nos esforzamos por ofrecer un ambiente cálido y seguro para nuestros gatitos, asegurando su bienestar y felicidad.\n" +
                    "Cada uno de nuestros gatitos es criado con dedicación y cuenta con atención veterinaria completa.\n" +
                    "Crecen en un entorno enriquecido, rodeados de cuidados y cariño para que, al llegar a su nuevo hogar, " +
                    "sean mascotas equilibradas y afectuosas.\n" +
                    "Nos enorgullecemos de seguir altos estándares de crianza y de brindar a" +
                    " cada familia un compañero de vida saludable y lleno de alegría.\n" +
                    "Te invitamos a conocer nuestro criadero y a encontrar el gatito perfecto para tu hogar.",
            fontSize = 18.sp,
            lineHeight = 24.sp,
            modifier = Modifier.padding(horizontal = mediumSpacing.dp)
        )

        InsertSpacer(n = smallPadding)

        //Botón para ir a ver los gatitos
        Button(onClick = { navController.navigate(route = "2-VerGatitos") },
            Modifier.width(buttonWidth.dp),
            shape = RoundedCornerShape(size = 15.dp)
        ) {
            Text(text = "Nuestros gatitos")
        }

        InsertSpacer(n = mediumSpacing)

        //Pie de página
        Text(
            text = "Adopta una Fiera © 2024 - Autor: Pablo Palanques Gil",
            fontSize = 12.sp,
            color = Color.DarkGray,
            modifier = Modifier
                .align(Alignment.CenterHorizontally)
                .padding(8.dp)
        )
    }
}