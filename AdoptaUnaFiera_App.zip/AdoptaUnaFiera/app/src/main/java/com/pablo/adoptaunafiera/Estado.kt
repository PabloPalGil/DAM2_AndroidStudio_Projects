package com.pablo.adoptaunafiera

enum class Estado {
    RESERVADO,
    DISPONIBLE
}