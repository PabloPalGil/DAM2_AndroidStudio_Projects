package com.pablo.adoptaunafiera

class Gatos(gatos: MutableList<Gato>) {
    var listaGatos = gatos

    //Método que devuelve el número de gatos
    fun getSize() : Int {
        return listaGatos.size
    }
}