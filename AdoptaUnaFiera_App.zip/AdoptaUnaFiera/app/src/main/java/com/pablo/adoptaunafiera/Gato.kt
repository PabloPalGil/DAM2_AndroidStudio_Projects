package com.pablo.adoptaunafiera

import java.time.LocalDate

data class Gato(val nom: String, val gen: Genero, var est: Estado, val fNac: LocalDate,
                val raz: Raza, var img: String) {
    val nombre = nom
    val genero = gen
    var estado = est
    val fNacim = fNac
    val raza = raz
    var imageUrl = img
}