package com.pablo.adoptaunafiera

enum class Genero {
    MACHO,
    HEMBRA
}