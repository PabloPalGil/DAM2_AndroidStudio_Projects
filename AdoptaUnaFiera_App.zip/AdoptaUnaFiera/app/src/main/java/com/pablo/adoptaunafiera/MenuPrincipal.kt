package com.pablo.adoptaunafiera

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.pablo.adoptaunafiera.ui.theme.courgetteFont
import com.pablo.adoptaunafiera.ui.theme.lucidaSansFont
import kotlinx.coroutines.delay
import kotlin.system.exitProcess

//Definimos algunas variables para un diseño consistente
val minSpacing = 8
val mediumSpacing = 16
val largeSpacing = 44
val buttonWidth = 200
val titleTextSize = 44
val largeTextSize = 32
val mediumTextSize = 16
val smallTextSize = 10


@Composable
fun menuPrincipal(navController: NavController){
    orientacion()//Comprobamos la orientación

    //Ponemos t0do en un Box para poder ubicar el nombre + imagen en la parte inferior
    Box(modifier = Modifier
        .fillMaxSize()
        .padding(smallPadding.dp)){
        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState()), //Con posibilidad de hacer scroll,
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Image(
                painter = painterResource(id = R.drawable.logo),
                contentDescription = "Adopta una Fiera",
                modifier = Modifier.requiredSize(200.dp)
            )
            //Título de la app
            Text(text = "Adopta una Fiera", fontSize = titleTextSize.sp,
                fontFamily = courgetteFont)

            InsertSpacer(largeSpacing)//Espacio entre el título y los botones

            //Definimos los botones
            //La disposición de los botones dependerá de la orientación:
            if(!landscape){ //Layout en orientación VERTICAL:
                BotonesPortrait(navController)
            } else { //Layout en orientación HORIZONTAL:
                BotonesLandscape(navController)
            }

            InsertSpacer(largeSpacing)//Espacio entre el título y los botones

            //Después de los botones ponemos nuestro nombre y una imagen
            Row(verticalAlignment = Alignment.CenterVertically){
                Image(
                    painter = painterResource(id = R.drawable.logo),
                    contentDescription = "Autor: Pablo Palanques Gil",
                    modifier = Modifier.requiredSize(50.dp)
                )
                //Mi nombre
                Text(text = "Pablo Palanques Gil", fontSize = smallTextSize.sp,
                    fontFamily = lucidaSansFont)
            }
        }
    }
}



@Composable
private fun BotonesLandscape(navController: NavController) {
    Row() {
        Button(onClick = { navController.navigate(route = "2-VerGatitos") },
            Modifier.width(buttonWidth.dp),
            shape = RoundedCornerShape(size = 15.dp)
        ) {
            Text(text = "Ver gatitos")
        }

        InsertSpacer(mediumSpacing)//Espacio entre botones

        Button(onClick = { navController.navigate(route = "3-QuieroAdoptar") },
            Modifier.width(buttonWidth.dp),
            shape = RoundedCornerShape(size = 15.dp)
        ) {
            Text(text = "Quiero adoptar")
        }
    }
    Row() {
        Button(onClick = { navController.navigate(route = "4-Conocenos") },
            Modifier.width(buttonWidth.dp),
            shape = RoundedCornerShape(size = 15.dp)
        ) {
            Text(text = "Conócenos")
        }

        InsertSpacer(mediumSpacing)

        Button(onClick = { exitProcess(0) }, Modifier.width(buttonWidth.dp),
            shape = RoundedCornerShape(size = 15.dp)
        ) {
            Text(text = "Salir")
        }
    }
}


@Composable
private fun BotonesPortrait(navController: NavController) {
    Button(
        onClick = { navController.navigate(route = "2-VerGatitos") },
        Modifier.width(buttonWidth.dp),
        shape = RoundedCornerShape(size = 15.dp)
    ) {
        Text(text = "Ver gatitos")
    }

    InsertSpacer(minSpacing)//Espacio entre botones

    Button(
        onClick = { navController.navigate(route = "3-QuieroAdoptar") },
        Modifier.width(buttonWidth.dp),
        shape = RoundedCornerShape(size = 15.dp)
    ) {
        Text(text = "Quiero adoptar")
    }

    InsertSpacer(minSpacing)

    Button(
        onClick = { navController.navigate(route = "4-Conocenos") },
        Modifier.width(buttonWidth.dp),
        shape = RoundedCornerShape(size = 15.dp)
    ) {
        Text(text = "Conócenos")
    }

    InsertSpacer(minSpacing)

    Button(
        onClick = { exitProcess(0) }, Modifier.width(buttonWidth.dp),
        shape = RoundedCornerShape(size = 15.dp)
    ) {
        Text(text = "Salir")
    }
}

