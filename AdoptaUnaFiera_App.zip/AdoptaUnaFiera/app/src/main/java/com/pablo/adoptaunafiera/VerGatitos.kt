package com.pablo.adoptaunafiera

import androidx.compose.animation.core.ArcAnimationSpec
import androidx.compose.foundation.background
import androidx.compose.material3.Switch
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.pablo.adoptaunafiera.ui.theme.lucidaSansFont

//Función que inserta la información de cada gatito
@Composable
fun verGatitos(navController: NavController) {
    //Definimos los estados
    var switchState by rememberSaveable { mutableStateOf(false) }



    //Comprobamos la orientación
    orientacion()

    //Organizamos en filas
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()), //Con posibilidad de hacer scroll
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ){
        //Título de la pantalla
        Text(text = "Nuestros gatitos", fontSize = titleTextSize.sp,
            fontFamily = lucidaSansFont
        )

        InsertSpacer(largeSpacing)//Espacio entre el título y los botones

        //Añadimos un switch para filtrar por gatos disponibles
        Text(
            text = "Mostrar sólo gatitos disponibles",
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground
        )
        Switch(
            checked = switchState,
            onCheckedChange = { switchState = it }
        )

        //Por cada gato en nuestra lista de gatitos, creamos una entrada
        gatos.listaGatos.forEach { gato ->
            //Si tenemos el switch activado, no mostraremos a los gatos no disponibles
            if(switchState && gato.estado != Estado.DISPONIBLE){
                //No mostramos este gato
            } else{
                //Organizamos cada gato en una fila de dos columnas, siendo la primera para la foto y
                //la segunda para los datos del mismo.
                Row(modifier = Modifier
                    .fillMaxWidth()
                    .height(300.dp)
                    .padding(smallPadding.dp)
                    .background(color = MaterialTheme.colorScheme.background),
                    verticalAlignment = Alignment.CenterVertically, //Centra los elementos verticalmente
                    ){
                    Column(modifier = Modifier
                        .weight(if(landscape) 2f else 1f),
                        horizontalAlignment = Alignment.CenterHorizontally){
                        //Añadimos la imagen de internet según la URL de la clase Gato:
                        AsyncImage(
                            model = ImageRequest.Builder(LocalContext.current)
                                .data(gato.imageUrl)
                                    .build(),
                            contentDescription = "Foto de ${gato.nombre}",
                        //Forzamos la imagen a ocupar los límites, mantiendo la rel. de aspecto
                            contentScale = ContentScale.Fit,
                        )
                    }

                    InsertSpacer(minSpacing)//Espaciamos un poco entre la foto y los datos

                    Column(modifier = Modifier
                        .weight(1f),
                        horizontalAlignment = Alignment.CenterHorizontally){
                        //Detallamos la información del gato
                        Text(text = "${gato.estado}",
                            fontSize = 24.sp,
                            fontFamily = lucidaSansFont,
                            modifier = Modifier.fillMaxWidth(),
                            color = if(gato.estado == Estado.DISPONIBLE) Color(0xFF1F4B00)
                            else Color(0xFF5F0000)
                        )
                        Text(text = "Nombre: ${gato.nombre}\n" +
                                "Género: ${gato.genero}\n" +
                                "Fecha de nacimiento: ${gato.fNacim}\n" +
                                "Raza: ${gato.raza}\n",
                            fontSize = 20.sp,
                            fontFamily = lucidaSansFont,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = minSpacing.dp)
                        )

                        Button(onClick = { navController.navigate(route = "3-QuieroAdoptar") },
                            Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(size = 15.dp)
                        ) {
                            Text(text = "¡Adóptame!")
                        }
                    }
                }

                //Tras cada gato, añadimos un espacio
                InsertSpacer(largeSpacing)
            }
        }

        InsertSpacer(n = mediumSpacing)

        Button(onClick = { navController.navigate(route = "1-MenuPrincipal") },
            Modifier.width(buttonWidth.dp),
            shape = RoundedCornerShape(size = 15.dp)
        ) {
            Text(text = "Volver")
        }

        InsertSpacer(n = mediumSpacing)
    }
}