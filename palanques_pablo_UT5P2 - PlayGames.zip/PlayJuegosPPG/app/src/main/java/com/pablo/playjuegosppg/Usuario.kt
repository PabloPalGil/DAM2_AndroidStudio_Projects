package com.pablo.playjuegosppg

import androidx.annotation.DrawableRes

//data clas Usuario para el Reto de UT4-P1-Ej2
data class Usuario(
    val name: String,
    val surname: String,
    val nick: String,
    val phone: String,
    val email: String,
    //Variables para UT4-P1-Ej5:
    var puntos: Int = 0,
    @DrawableRes val imgId: Int
)
