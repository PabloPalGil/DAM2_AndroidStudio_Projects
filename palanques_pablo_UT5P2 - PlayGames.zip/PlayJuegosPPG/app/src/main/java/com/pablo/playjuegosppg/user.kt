package com.pablo.playjuegosppg

import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FabPosition
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController

@Composable
fun user(navController: NavController) {
    val context = LocalContext.current
    val usuarios = getUsers()

    //Añadimos la TopAppBar (UT5-P2-Ej4)
    Scaffold(
        // Barra superior
        topBar = {
            TopAppBarUser()// La barra superior
        },
        //Snackbar
        snackbarHost = { },
        // Barra inferior
        bottomBar = { },
        //Código que hará el FAB
        floatingActionButton = {
            userFAB(fnFab = {
                Toast.makeText(
                    context, "¡Hola, soy un FAB!.",
                    Toast.LENGTH_SHORT
                ).show()
            })
        },
        floatingActionButtonPosition = FabPosition.Start, //Posición del FAB
        // Contenido principal
        content = { paddingValues ->
            //Implementamos el LazyColumn de usuarios:
            LazyColumn(
                modifier = Modifier.padding(paddingValues),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                //Recorremos tantos items como usuarios tenemos
                items(usuarios.size) { indice ->
                    //Generamos una fila por cada usuario
                    userCard(usuarios[indice]) {
                        //Implementamos el toast, en este caso el clic se
                        // devuelve como una lambda y ejecuta el cógido entre las llaves:
                        Toast.makeText(
                            context,
                            "${usuarios[indice].name} ${usuarios[indice].surname}",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }
            }
        }
    )
}

//Función que crea una Card por usuario
@Composable
fun userCard(usuario: Usuario, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(cardHeight.dp * 1.5f)
            .padding(vertical = 8.dp)
            //Definimos la Card clicable y le provocamos un retorno de clic mediante una lambda: () ->
            .clickable { onClick() },
        shape = RoundedCornerShape(0.dp)
    ) {
        Row(
            horizontalArrangement = Arrangement.Center,
        ) {
            //La imagen en local:
            Image(
                painter = painterResource(id = usuario.imgId),
                contentDescription = "Usuario ${usuario.name} ${usuario.surname}",
                //Forzamos la imagen a ocupar los límites, mantiendo la rel. de aspecto
                contentScale = ContentScale.FillWidth,
                modifier = Modifier.weight(1f)
            )

            //Etiquetas de texto:
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .align(Alignment.CenterVertically),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "${usuario.name} ${usuario.surname}",
                    fontSize = 20.sp,
                )
                Text(
                    text = "Puntos: ${usuario.puntos}",
                    fontSize = 12.sp,
                )
            }
        }
    }
}

@Composable
fun userFAB(fnFab: () -> Unit) {
    FloatingActionButton(
        onClick = { fnFab() }
    ) {
        Icon(
            imageVector = Icons.Filled.Add,
            contentDescription = "Add icon"
        )
    }
}


//Funcion que define la TopBar
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TopAppBarUser() {
    CenterAlignedTopAppBar(
        title = {
            Row(
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = "User", fontSize = 30.sp)
            }
        },
        navigationIcon = {
            IconButton(onClick = { }) {
                Icon(
                    imageVector = Icons.Default.Menu,
                    contentDescription = "Menu"
                )
            }
        },
        actions = {
            IconButton(onClick = {}) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "Add icon button"
                )
            }
            IconButton(onClick = { }) {
                Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = "Search icon button"
                )
            }
            IconButton(onClick = { }) {
                Icon(
                    imageVector = Icons.Default.MoreVert,
                    contentDescription = "More options (vertical)"
                )
            }
        },
        colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
            containerColor = MaterialTheme.colorScheme.secondary,
            titleContentColor = Color.White,
            navigationIconContentColor = Color.White,
            actionIconContentColor = Color.White
        )
    )
}
