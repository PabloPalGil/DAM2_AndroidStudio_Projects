package com.pablo.playjuegosppg

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults.buttonColors
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FabPosition
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldColors
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.pablo.playjuegosppg.ui.theme.colorPablo


val smallPadding = 16


//CON NAVEGACIÓN:
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NewPlayer(navController: NavController) {
    //Definimos las variables necesarias para los TextField
    var textName by rememberSaveable { mutableStateOf("") }
    var textSurname by rememberSaveable { mutableStateOf("") }
    var textNick by rememberSaveable { mutableStateOf("") }
    var textPhone by rememberSaveable { mutableStateOf("") }
    var textEmail by rememberSaveable { mutableStateOf("") }

    //Estados para almacenar los errores de los TextField (UT3-P1-Ej2)
    var fieldNameError by rememberSaveable { mutableStateOf(false) }
    var fieldNickError by rememberSaveable { mutableStateOf(false) }

    //Funcion que comprueba que se han rellenado los TextField Nombre y Nickname
    fun checkTextFields() {
        fieldNameError = textName.isEmpty()
        fieldNickError = textNick.isEmpty()
    }


    //Variables necesarias para manejar el ExposedDropDown Menu (UT4-P1-Ej1):
    val nickOptions = listOf("Blizzard", "Ryu578", "Kinton22", "Sasuke547", "Messi788")
    var expanded by rememberSaveable { mutableStateOf(false) }
    //Reto UT4-P1-Ej2
    val userOptions: List<Usuario> = getUsers()


    //Reto UT4-P1-Ej2
    //Función que autocompleta todos los TextField a partir del nick del user elegido:
    fun autoFillUser(user: Usuario) {
        textName = user.name
        textSurname = user.surname
        textPhone = user.phone
        textEmail = user.email
    }


    //Funcion que devuelve el color pasado como parámetro con un 15% de transparencia
    @Composable
    fun applyTransparency15(color: Color): Color {
        // Devolver el nuevo color con la transparencia ajustada al 15%:
        return color.copy(15 / 255f, color.red, color.green, color.blue)
    }


    //Función para personalizar los colores de TextField
    @Composable
    fun RepaintTextField(): TextFieldColors {
        //Si está en error, el fondo será rojo:
        if (fieldNameError) {
            return TextFieldDefaults.colors(errorContainerColor = MaterialTheme.colorScheme.errorContainer)
        } else {
            return TextFieldDefaults.colors(
                //Para que el reto no sobreescriba el color personal solicitado en UT2-P2-Ej3,
                //Pondremos el colorPersonal sólo de fondo cuando se selecciona un TextField
                focusedContainerColor = colorPablo,
                //reto UT2-P2-Ej3:
                unfocusedContainerColor = applyTransparency15(color = MaterialTheme.colorScheme.primary),
                focusedIndicatorColor = MaterialTheme.colorScheme.secondary
            )
        }
    }

    Orientacion()//Comprobamos la orientación

    //Añadimos la TopAppBar (UT5-P2-Ej2)
    Scaffold(
        // Barra superior
        topBar = {
            TopAppBarNewPlayer()// La barra superior
        },
        //Snackbar
        snackbarHost = { },
        // Barra inferior
        bottomBar = { },
        // Botón flotante personalizado
        floatingActionButton = {
            MyExtendedFAB(funcionFab = {checkTextFields()})
        },
        //Posición del FAB:
        floatingActionButtonPosition = FabPosition.Center,
        // Contenido principal
        content = { paddingValues ->
            Column( //Vamos a organizar el layout por filas
                Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .verticalScroll(rememberScrollState()), //Con posibilidad de hacer scroll
                horizontalAlignment = Alignment.CenterHorizontally, //Contenido centrado horizontalmente
                verticalArrangement = Arrangement.Top
            ) { //Organizando las filas desde la parte superior

                //Organizamos cada fila en columnas
                Row(Modifier.fillMaxSize()) {
                    //El primer elemento es un icono:
                    Image(
                        painter = painterResource(id = R.drawable.icon_person),
                        contentDescription = "Name",
                        modifier = Modifier
                            .weight(pesoMenor)
                            .size(60.dp)
                    )

                    //El segundo elemento es un campo de texto
                    TextField(
                        value = textName,  // El valor actual del campo de texto
                        onValueChange = { newText ->  // "newText" es el String escrito por el usuario
                            textName = newText  // Actualizamos el estado con el nuevo valor
                        },
                        label = { Text("Nombre") }, // Etiqueta
                        //placeholder = {Text("Nombre")},//Pista que aparece cuando está en blanco
                        modifier = Modifier
                            .weight(pesoMayor) //Ajustamos el tamaño del TextField
                            .padding(10.dp),
                        colors = RepaintTextField(), //Función que pinta el TextField de forma personalizada,
                        shape = RoundedCornerShape( //Reto UT2-P2-Ej3
                            topStart = 15.dp,
                            topEnd = 15.dp
                        ),
                        isError = fieldNameError //Si da error, resaltar el error
                    )
                }
                //Ponemos un Text justo debajo del Field obligatorio
                if (fieldNameError) {
                    Text(
                        text = "Error: Obligatorio",
                        color = MaterialTheme.colorScheme.error,
                        modifier = Modifier
                            .padding(bottom = 8.dp)
                    )
                } else {
                    Text(
                        text = "*Obligatorio",
                        color = MaterialTheme.colorScheme.secondary,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                }

                InsertSpacer(n = smallPadding)//Separación entre filas

                Row(Modifier.fillMaxSize()) {
                    //Dejamos el hueco del primer elemento porque no hay icono:
                    Spacer(Modifier.weight(pesoMenor))

                    //El segundo elemento es un campo de texto
                    TextField(
                        value = textSurname,  // El valor actual del campo de texto
                        onValueChange = { newText ->  // "newText" es el String escrito por el usuario
                            textSurname = newText  // Actualizamos el estado con el nuevo valor
                        },
                        label = { Text("Apellido") }, // Etiqueta
                        //placeholder = {Text("Apellidos")},//Pista que aparece cuando está en blanco
                        modifier = Modifier
                            .weight(pesoMayor)
                            .padding(10.dp),
                        colors = RepaintTextField(), //Función que pinta el TextField de forma personalizada,
                        shape = RoundedCornerShape( //Reto UT2-P2-Ej3
                            topStart = 15.dp,
                            topEnd = 15.dp
                        )
                    )
                }

                InsertSpacer(n = smallPadding)//Separación entre filas

                Row(Modifier.fillMaxSize()) {
                    //El primer elemento es un icono:
                    Image(
                        painter = painterResource(id = R.drawable.icon_nickname),
                        contentDescription = "Nickname",
                        modifier = Modifier
                            .weight(pesoMenor)
                            .size(60.dp)
                    )

                    //El segundo elemento lo sustituimos por un Box
                    // que contendrá el TextField y el ExposedDropDownMenu
                    ExposedDropdownMenuBox(
                        expanded = expanded,
                        onExpandedChange = { expanded = !expanded },
                    ) {
                        TextField(
                            modifier = Modifier
                                .menuAnchor()
                                .weight(pesoMayor)  //Ajustamos el tamaño del TextField al ancho completo
                                .padding(10.dp),
                            readOnly = false,
                            value = textNick,
                            onValueChange = { newText ->  // "newText" es el String escrito por el usuario
                                textNick = newText  // Actualizamos el estado con el nuevo valor
                            },
                            label = { Text("Nickname") },
                            //placeholder = {Text("Nickname")},//Pista que aparece cuando está en blanco
                            trailingIcon = {
                                ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded)
                            },
                            colors = ExposedDropdownMenuDefaults.textFieldColors(),
                            shape = RoundedCornerShape( //Reto UT2-P2-Ej3
                                topStart = 15.dp,
                                topEnd = 15.dp
                            ),
                            isError = fieldNickError //Si da error, resaltar el error
                        )
                        ExposedDropdownMenu(
                            expanded = expanded,
                            onDismissRequest = { expanded = false },
                        ) {
                            //RETO UT4-P1-Ej2
                            userOptions.forEach { selectionOption ->
                                DropdownMenuItem(
                                    text = { Text(selectionOption.nick) },
                                    onClick = {
                                        textNick = selectionOption.nick
                                        expanded = false
                                        autoFillUser(selectionOption)
                                    },
                                    contentPadding =
                                    ExposedDropdownMenuDefaults.ItemContentPadding,
                                )
                            }
                        }
                    }
                }

                //Ponemos un Text justo debajo del Field obligatorio
                if (fieldNickError) {
                    Text(
                        text = "Error: Obligatorio",
                        color = MaterialTheme.colorScheme.error,
                    )
                } else {
                    Text(
                        text = "*Obligatorio",
                        color = MaterialTheme.colorScheme.secondary,
                    )
                }

                InsertSpacer(n = smallPadding)//Separación entre filas

                Row(Modifier.fillMaxSize()) {
                    //Dejamos el hueco del primer elemento porque no hay icono:
                    Spacer(Modifier.weight(pesoMenor))

                    //El segundo elemento es otra image
                    Image(
                        painter = painterResource(id = R.drawable.android),
                        contentDescription = "Android imagen",
                        modifier = Modifier
                            .weight(pesoMenor * 0.8f)
                            .size(100.dp)
                    )

                    //El tercer elemento es un Button que ubicaremos como hijo de una Box:
                    Box(
                        modifier = Modifier
                            .weight(pesoMenor * 1.2f)
                            .align(Alignment.CenterVertically),
                        contentAlignment = Alignment.CenterStart
                    ) {
                        Button(
                            onClick = {},
                            Modifier
                                .padding(0.dp)
                                .fillMaxWidth()
                                .height(35.dp),
                            colors = buttonColors(
                                containerColor = MaterialTheme.colorScheme.error,
                            )
                        ) {
                            Text(text = "Preferences")
                        }
                    }
                }

                InsertSpacer(n = smallPadding)//Separación entre filas

                Row(Modifier.fillMaxSize()) {
                    //El primer elemento es un icono:
                    Image(
                        painter = painterResource(id = R.drawable.icon_phone),
                        contentDescription = "Phone",
                        modifier = Modifier
                            .weight(pesoMenor)
                            .size(60.dp)
                    )

                    //El segundo elemento es un campo de texto
                    TextField(
                        value = textPhone,  // El valor actual del campo de texto
                        onValueChange = { newText ->  // "newText" es el String escrito por el usuario
                            textPhone = newText  // Actualizamos el estado con el nuevo valor
                        },
                        //label = { Text("Teléfono") }, // Etiqueta
                        placeholder = { Text("Teléfono") },//Pista que aparece cuando está en blanco
                        modifier = Modifier
                            .weight(pesoMayor) // Ajustamos el tamaño del TextField
                            .padding(10.dp),
                        colors = RepaintTextField(), //Función que pinta el TextField de forma personalizada,
                        shape = RoundedCornerShape( //Reto UT2-P2-Ej3
                            topStart = 15.dp,
                            topEnd = 15.dp
                        )
                    )
                }

                InsertSpacer(n = smallPadding)//Separación entre filas

                Row(Modifier.fillMaxSize()) {
                    //El primer elemento es un icono:
                    Image(
                        painter = painterResource(id = R.drawable.icon_email),
                        contentDescription = "Email",
                        modifier = Modifier
                            .weight(pesoMenor)
                            .size(60.dp)
                    )

                    //El segundo elemento es un campo de texto
                    TextField(
                        value = textEmail,  // El valor actual del campo de texto
                        onValueChange = { newText ->  // "newText" es el String escrito por el usuario
                            textEmail = newText  // Actualizamos el estado con el nuevo valor
                        },
                        label = { Text("Email") }, // Etiqueta
                        //placeholder = {Text("Email")},//Pista que aparece cuando está en blanco
                        modifier = Modifier
                            .weight(pesoMayor) // Ajustamos el tamaño del TextField
                            .padding(10.dp),
                        colors = RepaintTextField(), //Función que pinta el TextField de forma personalizada,
                        shape = RoundedCornerShape( //Reto UT2-P2-Ej3
                            topStart = 15.dp,
                            topEnd = 15.dp
                        )
                    )
                }

                InsertSpacer(n = smallPadding)//Separación entre filas

                //Cambiamos el botón por un FAB (UT5-P2-Ej2):
//                Button(
//                    onClick = { checkTextFields() },
//                    modifier = Modifier.fillMaxWidth(0.5f)
//                ) {
//                    Text(text = "Add new player", modifier = Modifier.padding(5.dp))
//                }
//                InsertSpacer(n = smallPadding)//Separación entre filas
            }
        }
    )
}


//Funcion que define la TopBar
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TopAppBarNewPlayer() {
    //Estado para controlar si el menú está desplegado o no
    var menuExpanded by remember { mutableStateOf(false) }

    //Variable de estado para el icono corazón
    var favIcon by rememberSaveable { mutableStateOf(false) }

    CenterAlignedTopAppBar(
        title = {
            Row(
                Modifier.padding(10.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = "New Player", fontSize = 30.sp)
            }
        },
        navigationIcon = {
            IconButton(onClick = { }) {
                Icon(
                    imageVector = Icons.Default.Menu,
                    contentDescription = "Menu"
                )
            }
        },
        actions = {
            IconButton(onClick = {
                favIcon = !favIcon
            }) {
                if (!favIcon) {
                    Icon(
                        imageVector = Icons.Default.Favorite,
                        contentDescription = "Favorite filled icon button"
                    )
                } else {
                    Icon(
                        imageVector = Icons.Default.FavoriteBorder,
                        contentDescription = "Favorite empty icon button"
                    )
                }
            }
            IconButton(onClick = { }) {
                Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = "Search icon button"
                )
            }
            IconButton(onClick = { menuExpanded = true }) {
                Icon(
                    imageVector = Icons.Default.MoreVert,
                    contentDescription = "More options (vertical)"
                )
            }
        },
        colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
            containerColor = MaterialTheme.colorScheme.secondary,
            titleContentColor = Color.White,
            navigationIconContentColor = Color.White,
            actionIconContentColor = Color.White
        )
    )
}

//Funcion que crea un FAB con texto
@Composable
fun MyExtendedFAB(funcionFab: () -> Unit) {
    ExtendedFloatingActionButton(
        onClick = { funcionFab() },
        icon = { Icon(Icons.Filled.AccountCircle, "FAB para añadir el nuevo player.") },
        text = {
            Text(text = "Add new player")
        },
        containerColor = MaterialTheme.colorScheme.secondary,
        contentColor = Color.White
    )
}