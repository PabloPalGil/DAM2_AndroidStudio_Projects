package com.pablo.playjuegosppg

import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.StarHalf
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.outlined.Star
import androidx.compose.material.icons.outlined.StarOutline
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FabPosition
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.pablo.playjuegosppg.ui.theme.courgetteFont
import kotlin.math.floor
import kotlin.math.round


@Composable
fun Preferences(navController: NavController) {
    //Variable para gestionar el estado del radio button seleccionado
    var estadoRadio by rememberSaveable { mutableStateOf("") }

    //Creamos las opciones de los radio buttons:
    val gameOptions = listOf(
        "Angry Birds", "Dragon Fly", "Hill Climbing Racing",
        "Pocket Soccer", "Radiant Defense"
    )

    //Variables del slider discreto
    var selectionSlider by rememberSaveable { mutableStateOf(5.0) }//Estado del slider
    val range = 0f..5f//Valores min y max
    //step es para que la slider sea discreta en lugar de continua
    //val step = 5//Pasos intermedios de un extremo al otro

    var context = LocalContext.current//Usaremos el contexto local en el FAB

    //Variable de la etiqueta de la reseña según la selección
    var review by rememberSaveable { mutableStateOf("Reseña personal: juego no seleccionado") }

    //Definimos la variable de estado del TextField de la reseña
    var textReview by rememberSaveable { mutableStateOf("") }

    //Definimos las variables para pintar un texto con varios colores:
    val someColors: List<Color> = listOf(
        Color(0xFF6A1B9A), Color(0xFFE03F1A),
        Color(0xFFF9A825), Color(0xFF2E7D32), Color(0xFF1565C0)
    )

    val brush = remember {
        Brush.linearGradient(
            colors = someColors
        )
    }

    //Definimos una lista clave-valor para asociar cada String de gameOptions con su imagen correspondiente
    //y poder cargar las imágenes con una sola línea en el forEach que crea los RadioButton.
    //No es la manera más eficiente de proceder, pero así practicamos con este tipo de listas:
    val imgRadios = mapOf(
        "Angry Birds" to R.drawable.games_angrybirds,
        "Dragon Fly" to R.drawable.games_dragonfly,
        "Hill Climbing Racing" to R.drawable.games_hillclimbingracing,
        "Pocket Soccer" to R.drawable.games_pocketsoccer,
        "Radiant Defense" to R.drawable.games_radiantdefense
    )

    //Definimos las variables de estado de los Switch:
    var switchCompletado by rememberSaveable { mutableStateOf(false) }
    var switchGuardarComent by rememberSaveable { mutableStateOf(false) }

    //Añadimos la TopAppBar (UT5-P2-Ej4)
    Scaffold(
        // Barra superior
        topBar = {
            TopAppBarPreferences()// La barra superior
        },
        //Snackbar
        snackbarHost = { },
        // Barra inferior
        bottomBar = { },
        //Código que hará el FAB según le paso a mi función MyFAB()
        //(ponemos la lambda aquí para alcanzar la variable estadoRadio sin problemas)
        floatingActionButton = {
            MyFAB(fnFab = {
                if (estadoRadio == "") {
                    Toast.makeText(
                        context, "No has pulsado ninguna opción.",
                        Toast.LENGTH_LONG
                    ).show()
                } else {
                    Toast.makeText(
                        context, "$estadoRadio Puntuación" +
                                " ${roundToHalf(selectionSlider)}",
                        Toast.LENGTH_LONG
                    ).show()
                }
            })
        },
        floatingActionButtonPosition = FabPosition.End, //Posición del FAB
        // Contenido principal
        content = { paddingValues ->
            Column(
                Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .verticalScroll(rememberScrollState()), //Con posibilidad de hacer scroll
                horizontalAlignment = Alignment.Start, //Contenido a la izquierda de la pantalla
                verticalArrangement = Arrangement.Top
            ) //Organizamos el contenido de arriba abajo
            {
                //El primer elemento es un Text:
                Text(
                    text = "Elige una opción:", fontSize = 20.sp,
                    color = MaterialTheme.colorScheme.primary,
                    fontFamily = courgetteFont
                )

                InsertSpacer(mediumSpacing)//Espacio entre el texto y los radio buttons

                //Vamos colocando los radio buttons en rows con su respectiva etiqueta:
                gameOptions.forEach { item ->
                    Row(
                        verticalAlignment = Alignment.CenterVertically, //Centra los elementos verticalmente
                        modifier = Modifier.padding(horizontal = 16.dp)
                    ) {
                        RadioButton(selected = estadoRadio == item, onClick = {
                            estadoRadio = item
                            review = "Reseña personal de $estadoRadio"
                        })
                        //Colocamos la imagen de cada radioButton:
                        Image(
                            painter = painterResource(id = imgRadios[item]!!),//Le decimos al compilador que confie con !!
                            contentDescription = "Imagen para $item",
                            modifier = Modifier
                                .padding(end = 8.dp), //Espacio entre la imagen y el texto
                            contentScale = ContentScale.FillHeight
                        )
                        //Colocamos el Text
                        Text(text = item)
                    }
                    InsertSpacer(n = minSpacing)
                }

                InsertSpacer(n = mediumSpacing)

                //Colocamos la Star Rating bar justo antes del slider:
                RatingBar(
                    rating = selectionSlider,
                    stars = 5
                )//inicializamos por defecto con 5 stars

                InsertSpacer(n = smallPadding)

                //Colocamos el slider discreto
                Slider(
                    value = selectionSlider.toFloat(),
                    valueRange = range,
                    //steps = step,//Hacemos el Slider continuo en lugar de discreto
                    onValueChange = { selectionSlider = it.toDouble() }
                )
                //Text(text = selectionSlider.toInt().toString())
                Text(text = roundToHalf(selectionSlider).toString())

                InsertSpacer(n = mediumSpacing)

                //Etiqueta de la reseña:
                //review se actualiza al pulsar un radio Button
                Text(
                    text = review, fontSize = 20.sp,
                    fontFamily = courgetteFont,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(start = smallPadding.dp)
                )

                //Añadimos el TextField donde escribir la reseña:
                TextField(
                    value = textReview,  //El valor actual del campo de texto
                    onValueChange = {
                        textReview = it
                    },  //Actualizamos el estado con el nuevo valor
                    modifier = Modifier
                        .fillMaxWidth() //Ajustamos el tamaño del TextField
                        .height(100.dp)
                        .padding(10.dp),
                    textStyle = TextStyle(brush = brush), //Función que pinta el TextField de forma personalizada,
                )

                InsertSpacer(n = mediumSpacing)
                //Para centrar cada switch junto con su etiqueta de texto, los distribuiremos en 2
                //columnas iguales dentro de una misma Fila:
                Row(modifier = Modifier.fillMaxWidth()) {
                    Column(
                        modifier = Modifier
                            .weight(1f) //Ambas columnas tendrán el mismo peso
                            .padding(smallPadding.dp),
                        horizontalAlignment = Alignment.Start
                    ) {//Se alinean a la izquierda
                        Text(
                            text = "Juego completado",
                            modifier = Modifier.padding(vertical = smallSpacing.dp)
                        )
                        Switch(
                            checked = switchCompletado,
                            onCheckedChange = { switchCompletado = it }
                        )
                    }

                    InsertSpacer(n = mediumSpacing)//Espacio entre las dos columnas

                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .padding(smallPadding.dp),
                        horizontalAlignment = Alignment.Start
                    ) {
                        Text(
                            text = "Guardar comentario",
                            modifier = Modifier.padding(vertical = smallSpacing.dp)
                        )
                        Switch(
                            checked = switchGuardarComent,
                            onCheckedChange = { switchGuardarComent = it }
                        )
                    }
                }
            }
        }
    )
}


//Función que genera un rating de estrellas (5 estrellas por defecto)
//Con una precisión de 0.5 puntos para darle sentido al icono de media estrella
@Composable
fun RatingBar(
    rating: Double = 0.0,//Si no pasamos parámetro inicializamos en 0.0
    stars: Int = 5,//Por defecto se puntúa sobre 5 estrellas
    starsColor: Color = MaterialTheme.colorScheme.inversePrimary//El color de las estrellas
) {
    val filledStars = floor(rating).toInt() //Redondeamos a la baja las estrellas llenas

    //x.rem(1) equivale a obtener la parte decimal de x (esto dará true sólo si la parte
    // decimal no es cercana a 0). Ampliamos el rango a la precisión buscada de 0.5 puntos:
    val halfStar = !(rating.rem(1) in -0.25..0.25)

    //Restamos las estrellas llenas y medio llenas al total de estrellas para
    // obtener las estrellas completamente vacías
    var unfilledStars = 0
    if (halfStar)
        unfilledStars = stars - filledStars - 1
    else
        unfilledStars = stars - filledStars

    Row(
        modifier = Modifier.fillMaxWidth(0.9f),
        horizontalArrangement = Arrangement.SpaceAround
    ) {
        repeat(filledStars) {//Generamos las estrellas llenas
            Icon(
                imageVector = Icons.Outlined.Star, contentDescription = null, tint = starsColor,
                modifier = Modifier.size(50.dp)
            )//Les damos 50.dp para que se vena mejor
        }

        //Si el rating tiene parte decimal, generamos una media-estrella
        if (halfStar) {
            Icon(
                imageVector = Icons.AutoMirrored.Outlined.StarHalf,
                contentDescription = null,
                tint = starsColor,
                modifier = Modifier.size(50.dp)//Les damos 50.dp para que se vena mejor
            )
        }

        //Generamos las estrellas vacías
        repeat(unfilledStars) {
            Icon(
                imageVector = Icons.Outlined.StarOutline,
                contentDescription = null,
                tint = starsColor,
                modifier = Modifier.size(50.dp)//Les damos 50.dp para que se vena mejor
            )
        }
    }
}

//Función para redondear un numero real a incrementos de 0.5:
fun roundToHalf(d: Double): Double {
    return round(d * 2) / 2
}


//Funcion que define la TopBar
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TopAppBarPreferences() {
    CenterAlignedTopAppBar(
        title = {
            Row(
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = "Preferences", fontSize = 30.sp)
            }
        },
        navigationIcon = {
            IconButton(onClick = { }) {
                Icon(
                    imageVector = Icons.Default.Menu,
                    contentDescription = "Menu"
                )
            }
        },
        actions = { },
        colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
            containerColor = MaterialTheme.colorScheme.secondary,
            titleContentColor = Color.White,
            navigationIconContentColor = Color.White,
            actionIconContentColor = Color.White
        )
    )
}

@Composable
fun MyFAB(fnFab: () -> Unit) {
    FloatingActionButton(
        onClick = { fnFab() }
    ) {
        Icon(
            imageVector = Icons.Filled.Check, contentDescription
            = "Check"
        )
    }
}