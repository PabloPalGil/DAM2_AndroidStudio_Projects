package com.pablo.playjuegosppg


import android.widget.Toast
import androidx.compose.foundation.clickable

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Done
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import coil.compose.AsyncImage
import coil.request.ImageRequest

//Funcion que devuelve la lista de generos (clase Genre)
fun getGenres(): List<Genre> {
    return listOf(
        Genre(
            "Aventura", "The Legend Of Zelda: BotW",
            "https://www.nintendo.com/eu/media/images/10_share_images/games_15/wiiu_14/SI_WiiU_TheLegendOfZeldaBreathOfTheWild_image1600w.jpg"
        ),
        Genre(
            "Acción", "Tomb Raider",
            "https://static.wikia.nocookie.net/tomb-raider/images/a/ad/TR2013_Portada_cuadrada.png/revision/latest?cb=20180305194222&path-prefix=es"
        ),
        Genre(
            "RPG", "Octopath Traveler",
            "https://static.wikia.nocookie.net/octopath-traveler/images/6/63/CoverNA.png/revision/latest?cb=20190505005927"
        ),
        Genre(
            "Deportes", "NBA 2K25",
            "https://hoopshype.com/wp-content/uploads/sites/92/2024/07/2k25-tatum-1.jpeg?w=1000&h=600&crop=1"
        ),
        Genre(
            "Shooter", "Crysis",
            "https://media.vandal.net/ivandal/12/63/1200x630/52/5252/2007111901355_1.jpg"
        ),
        Genre(
            "Plataformas", "Super Mario 64",
            "https://m.media-amazon.com/images/I/61WDvKg7g9L._AC_UF894,1000_QL80_.jpg"
        ),
        Genre(
            "Estrategia", "Fire Emblem IV",
            "https://e.snmc.io/lk/lv/x/75fd1c4b502f8155e4c088b218cdfb9e/7272439"
        ),
        Genre(
            "Lucha", "Super Smash Bros. Melee",
            "https://m.media-amazon.com/images/M/MV5BMDUxOGU3OTUtNzI2OS00ZjNiLWFkZDUtMDMxZTA5Y2I4ZGU1XkEyXkFqcGc@._V1_.jpg"
        ),
        Genre(
            "Simulación", "Microsoft Flight Simulator",
            "https://cdn.dlcompare.com/game_tetiere/upload/gameimage/file/db7d-microsoft_flight_simulator_(2020).jpeg.webp"
        )
    )
}

@Composable
fun Play(navController: NavController) {
    val context = LocalContext.current

    //Variable con las plataformas:
    val platforms = listOf("PC", "Xbox S/X", "Switch", "PS5", "Megadrive", "Nintendo 64")

//    //Variables de estado de seleccion de los Chips de las plataformas:
//    val selectedPlatform = rememberSaveable { mutableStateListOf("") }

    //Variable con los géneros:
    val genres = getGenres()

    Orientacion()//Comprobamos la orientación

    //Añadimos la TopAppBar (UT5-P2-Ej3)
    Scaffold(
        // Barra superior
        topBar = {
            TopAppBarPlay()// La barra superior
        },
        //Snackbar
        snackbarHost = { },
        // Barra inferior
        bottomBar = { },
        // Contenido principal
        content = { paddingValues ->
            //Mostramos los elementos de arriba abajo
            Column(
                modifier = Modifier
                    .fillMaxWidth(0.9f)
                    .padding(paddingValues),
                horizontalAlignment = Alignment.Start,
                verticalArrangement = Arrangement.Top
            )
            {
                //Etiqueta de texto:
                Text(
                    text = "Plataformas:",
                    fontSize = medTextSize.sp,
                    modifier = Modifier
                        .padding(bottom = smallSpacing.dp)
                )

                //Función que implementa un LazyRow de plataformas:
                LazyRow(
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier
                        .padding(smallSpacing.dp)
                        .fillMaxWidth()
                ) {
                    //Recorremos cada plataforma de la lista y creamos un Chip
                    for (opcion in platforms) {
                        item {
                            FilterChip(opcion)
                            InsertSpacer(n = minSpacing)
                        }
                    }
                }

                InsertSpacer(n = smallSpacing)

                //Etiqueta de texto:
                Text(
                    text = "Géneros:",
                    fontSize = medTextSize.sp,
                    modifier = Modifier
                        .padding(bottom = smallSpacing.dp)
                )

                //Implementamos el LazyColumn de géneros:
                LazyColumn(
                    modifier = Modifier.padding(smallSpacing.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    //Recorremos tantos items como generos tenemos
                    items(genres.size) { indice ->
                        //Generamos una Card por cada género con su juego
                        genreCard(genres[indice]) {
                            //Implementamos el toast, en este caso el clic se
                            // devuelve como una lambda y ejecuta el cógido entre las llaves:
                            Toast.makeText(
                                context,
                                "Has seleccionado el género ${genres[indice].genero} y el juego ${genres[indice].juego}",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }
                }
            }
        }
    )
}


//Funcion que crea el FilterChip con la plataforma
@Composable
fun FilterChip(platform: String) {
    //Al crearse la variable de estado para cada Chip, se pueden seleccionar independientemente
    var selected by rememberSaveable { mutableStateOf(false) }

    //Creamos el filter Chip
    FilterChip(
        onClick = { selected = !selected },//Selección / deselección al clicar
        label = {
            Text("$platform")//El texto es la plataforma
        },
        selected = selected,//Si selected = true, indicamos que se seleccione
        leadingIcon = if (selected) {
            {
                Icon(
                    imageVector = Icons.Filled.Done,//icono en V
                    contentDescription = "Done icon",
                    modifier = Modifier.size(FilterChipDefaults.IconSize)
                )
            }
        } else {
            null
        }
    )
}


//Funcion que genera una Card a partir de un objeto de la clase Genre
@Composable
fun genreCard(genre: Genre, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(cardHeight.dp)
            .padding(vertical = 8.dp)
            //Definimos la Card clicable y le provocamos un retorno de clic mediante una lambda: () ->
            .clickable { onClick() },
        shape = RoundedCornerShape(8.dp)
    ) {
        Row(horizontalArrangement = Arrangement.Center) {
            //Etiqueta de texto (dentro de un Box para centrarla cómodamente):
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .align(Alignment.CenterVertically),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "${genre.genero}:",
                    fontSize = 16.sp,
                    modifier = Modifier
                        .padding(bottom = mediumSpacing.dp)
                )
            }

            //La imagen de internet:
            AsyncImage(
                model = ImageRequest.Builder(LocalContext.current)
                    .data(genre.imageUrl)
                    .build(),
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentDescription = "Imagen de ${genre.genero}",
                //Forzamos la imagen a ocupar el ancho, mantiendo la rel. de aspecto
                contentScale = ContentScale.FillWidth
            )
        }
    }
}

//Funcion que define la TopBar
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TopAppBarPlay() {
    //Estado para controlar si el menú está desplegado o no
    var menuExpanded by remember { mutableStateOf(false) }

    //Variable de estado para el icono corazón
    var favIcon by rememberSaveable { mutableStateOf(false) }

    CenterAlignedTopAppBar(
        title = {
            Row(
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = "Play", fontSize = 30.sp)
            }
        },
        navigationIcon = {
            IconButton(onClick = { }) {
                Icon(
                    imageVector = Icons.Default.Menu,
                    contentDescription = "Menu"
                )
            }
        },
        actions = {
            IconButton(onClick = {
                favIcon = !favIcon
            }) {
                if (!favIcon) {
                    Icon(
                        imageVector = Icons.Default.Favorite,
                        contentDescription = "Favorite filled icon button"
                    )
                } else {
                    Icon(
                        imageVector = Icons.Default.FavoriteBorder,
                        contentDescription = "Favorite empty icon button"
                    )
                }
            }
            IconButton(onClick = { }) {
                Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = "Search icon button"
                )
            }
            IconButton(onClick = { }) {
                Icon(
                    imageVector = Icons.Default.MoreVert,
                    contentDescription = "More options (vertical)"
                )
            }
        },
        colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
            containerColor = MaterialTheme.colorScheme.secondary,
            titleContentColor = Color.White,
            navigationIconContentColor = Color.White,
            actionIconContentColor = Color.White
        )
    )
}