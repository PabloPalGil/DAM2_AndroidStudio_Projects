package com.pablo.playjuegosppg

data class Genre(val genero: String, val juego: String, val imageUrl: String)
