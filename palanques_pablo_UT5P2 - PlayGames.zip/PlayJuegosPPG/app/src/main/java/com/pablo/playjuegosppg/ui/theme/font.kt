package com.pablo.playjuegosppg.ui.theme

import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import com.pablo.playjuegosppg.R


// Tipografía personalizada para la fuente externa
val courgetteFont = FontFamily(
    Font(R.font.courgette_regular, FontWeight.Normal)
)
