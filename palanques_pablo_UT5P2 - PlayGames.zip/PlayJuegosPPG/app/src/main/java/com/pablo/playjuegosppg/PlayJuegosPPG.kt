package com.pablo.playjuegosppg

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBox
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.DrawerState
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.pablo.playjuegosppg.ui.theme.courgetteFont
import kotlinx.coroutines.launch

//Definimos algunas variables para un diseño consistente
val minSpacing = 4
val smallSpacing = 8
val mediumSpacing = 16
val largeSpacing = 44
val buttonWidth = 200
val titleTextSize = 44
val bigTextSize = 32
val medTextSize = 24


@Composable
fun PlayJuegosPPG(navController: NavController){
    Orientacion()//Comprobamos la orientación

    //Variable para el ModalDrawer
    val mydrawerState = rememberDrawerState(initialValue = DrawerValue.Closed)

    //Añadimos el ModalDrawer y la TopAppBar (UT5-P2-Ej1)
    MyModalDrawer(drawerState = mydrawerState,
        contenido = {
            Scaffold(
                // Barra superior
                topBar = {
                    TopAppBarMainMenu(mydrawerState, navController)// La barra superior
                },
                //Snackbar
                snackbarHost = {  },
                // Barra inferior
                bottomBar = { },
                // Botón flotante personalizado
                floatingActionButton = { },
                // Contenido principal
                content = { paddingValues ->
                    Column(Modifier
                        .padding(paddingValues)
                        .fillMaxSize(),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.gameboy),
                            contentDescription = "GameBoy",
                            modifier = Modifier.requiredSize(150.dp)
                        )
                        //Título de la app
                        Text(text = "Play Games", fontSize = titleTextSize.sp,
                            fontFamily = courgetteFont) //UT2-P2-Ej4

                        InsertSpacer(largeSpacing)//Espacio entre el título y los botones

                        //Definimos los botones (de momento, sin funcionalidad)
                        //La disposición de los botones dependerá de la orientación:
                        if(!landscape){ //Layout en orientación VERTICAL:
                            BotonesPortrait(navController)
                        } else { //Layout en orientación HORIZONTAL:
                            BotonesLandscape(navController)
                        }
                    }
                }
            )
        }
    )
}

@Composable
private fun BotonesLandscape(navController: NavController) {
    Row() {
        Button(onClick = { navController.navigate(route = "4-Play") }, Modifier.width(buttonWidth.dp),
            shape = RoundedCornerShape(size = 15.dp)) {
            Text(text = "Play")
        }

        InsertSpacer(mediumSpacing)//Espacio entre botones

        Button(onClick = {navController.navigate(route = "3-Preferences")},
            Modifier.width(buttonWidth.dp),
            shape = RoundedCornerShape(size = 15.dp)) {
            Text(text = "Preferences")
        }
    }
    Row() {
        Button(onClick = { navController.navigate(route = "2-NewPlayer")},
            Modifier.width(buttonWidth.dp),
            shape = RoundedCornerShape(size = 15.dp)) {
            Text(text = "New Player")
        }

        InsertSpacer(mediumSpacing)

        Button(onClick = { navController.navigate(route = "5-Users") }, Modifier.width(buttonWidth.dp),
            shape = RoundedCornerShape(size = 15.dp)) {
            Text(text = "Users")
        }
    }
    Row() {
        Button(onClick = {}, Modifier.width(buttonWidth.dp),
            shape = RoundedCornerShape(size = 15.dp)) {
            Text(text = "About")
        }
    }
}

@Composable
private fun BotonesPortrait(navController: NavController) {
    Button(onClick = { navController.navigate(route = "4-Play") }, Modifier.width(buttonWidth.dp),
        shape = RoundedCornerShape(size = 15.dp)) {
        Text(text = "Play")
    }

    InsertSpacer(smallSpacing)//Espacio entre botones

    Button(onClick = { navController.navigate(route = "2-NewPlayer")},
        Modifier.width(buttonWidth.dp),
        shape = RoundedCornerShape(size = 15.dp)) {
        Text(text = "New Player")
    }

    InsertSpacer(smallSpacing)

    Button(onClick = {navController.navigate(route = "3-Preferences")},
        Modifier.width(buttonWidth.dp),
        shape = RoundedCornerShape(size = 15.dp)) {
        Text(text = "Preferences")
    }

    InsertSpacer(smallSpacing)

    Button(onClick = { navController.navigate(route = "5-Users") }, Modifier.width(buttonWidth.dp),
        shape = RoundedCornerShape(size = 15.dp)) {
        Text(text = "Users")
    }

    InsertSpacer(smallSpacing)

    Button(onClick = {}, Modifier.width(buttonWidth.dp),
        shape = RoundedCornerShape(size = 15.dp)) {
        Text(text = "About")
    }
}


//Función que devuelve una lista de datos de Users predefinidos:
fun getUsers(): List<Usuario> {
    return listOf(
        Usuario("Alfredo", "Frías", "Blizzard",
            "654112233", "ventiscas@gmail.com",
            1111, R.drawable.image1),
        Usuario("Ricardo", "Leches", "Ryu578",
            "661112233", "hadouken@gmail.com",
            2222, R.drawable.image2),
        Usuario("Maikel", "Jasón", "Kinton22",
            "623112233", "pinon@gmail.com",
            3333, R.drawable.image3),
        Usuario("Hugo", "Umbrales", "Sasuke547",
            "666112233", "sharingan@gmail.com",
            4444, R.drawable.image4),
        Usuario("Oliver", "Balones", "Messi788",
            "617112233", "barka@gmail.com",
            5555, R.drawable.image5),
        Usuario("Filemón", "Embutido", "TIA007",
            "677112233", "comic58@gmail.com",
            6666, R.drawable.image6),
        Usuario("Pablo", "Pedrales", "Gohan897",
            "699112233", "kameha@gmail.com",
            7777, R.drawable.image7),
        Usuario("Ximo", "Andalus", "Boqueron963",
            "655112233", "er_beti@gmail.com",
            8888, R.drawable.image8)

    )
}


//Funcion que define la TopBar
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TopAppBarMainMenu(
    drawerState: DrawerState,
    navController: NavController
) {
    //Estado para controlar si el menú está desplegado o no
    var menuExpanded by remember { mutableStateOf(false) }

    val corutina = rememberCoroutineScope()
    CenterAlignedTopAppBar(
        title = {
            Row(
                Modifier.padding(10.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = "Play Juegos", fontSize = 30.sp)
            }
        },
        navigationIcon = {
            IconButton(onClick = {
                corutina.launch {
                    drawerState.apply {
                        if (isClosed) open() else close()
                    }
                }
            }) {
                Icon(
                    imageVector = Icons.Default.Menu,
                    contentDescription = "Menu"
                )
            }
        },
        actions = {
            IconButton(onClick = { menuExpanded = true }) {
                Icon(
                    imageVector = Icons.Default.MoreVert,
                    contentDescription = "More options (vertical)"
                )
            }
            //Menú desplegable
            DropdownMenu(
                expanded = menuExpanded,
                onDismissRequest = { menuExpanded = false }
            ) {
                //Primera opción del menú
                DropdownMenuItem(
                    text = { Text("Types") },
                    onClick = {
                        menuExpanded = false
                        navController.navigate(route = "4-Play")
                    },
                    leadingIcon = {
                        Icon(Icons.Filled.AccountBox, contentDescription = "Types icon")
                    }
                )
                //Segunda opción del menú
                DropdownMenuItem(
                    text = { Text("Share") },
                    onClick = { },
                    leadingIcon = {
                        Icon(Icons.Filled.Share, contentDescription = "Share icon")
                    }
                )
            }
        },
        colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
            containerColor = MaterialTheme.colorScheme.secondary,
            titleContentColor = Color.White,
            navigationIconContentColor = Color.White,
            actionIconContentColor = Color.White
        )
    )
}


//Función que define el menú lateral ModalDrawer
@Composable
fun MyModalDrawer(
    drawerState: DrawerState,
    contenido: @Composable () -> Unit
) {
    val corutina = rememberCoroutineScope()

    ModalNavigationDrawer(
        drawerState = drawerState,
        gesturesEnabled = false,
        modifier = Modifier
            .clickable {
                corutina.launch {
                    drawerState.apply {
                        close()
                    }
                }
            },
        drawerContent = {
            ModalDrawerSheet(drawerTonalElevation = 100.dp) {
                NavBarHeader()
                NavigationDrawerItem(
                    label = { Text(text = "Home") },
                    selected = false,
                    onClick = {
                        corutina.launch {
                            drawerState.apply {
                                close()
                            }
                        }
                    },
                    icon = { Icon(Icons.Filled.Home, contentDescription = "Home icon") },
                )
                NavigationDrawerItem(
                    label = { Text(text = "Profiles") },
                    selected = false,
                    onClick = {
                        corutina.launch {
                            drawerState.apply {
                                close()
                            }
                        }
                    },
                    icon = { Icon(Icons.Filled.AccountCircle, contentDescription = "Profiles icon") },
                )
                NavigationDrawerItem(
                    label = { Text(text = "Settings") },
                    selected = false,
                    onClick = {
                        corutina.launch {
                            drawerState.apply {
                                close()
                            }
                        }
                    },
                    icon = { Icon(Icons.Filled.Settings, contentDescription = "Settings icon") },
                )
            }
        }
    ) {
        contenido()
    }
}


//Función que define la cabecera del ModalDrawer
@Composable
fun NavBarHeader() {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .wrapContentHeight(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Image(
            painter = painterResource(id = R.drawable.gameboy),
            contentDescription = "Play Juegos icon",
            contentScale = ContentScale.Fit,
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 30.dp)
                .requiredSize(150.dp)
                .clip(CircleShape)
        )
    }
}
