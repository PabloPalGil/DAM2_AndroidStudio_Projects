package com.pablo.playjuegosppg

import android.content.res.Configuration
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.pablo.playjuegosppg.ui.theme.PlayJuegosPersonal


//Variables para controlar orientación
var landscape = false
var pesoMenor = 0f
var pesoMayor = 0f
var cardHeight = 100

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //enableEdgeToEdge()
        setContent {
            //PlayJuegosTheme {
            PlayJuegosPersonal {
                //CON NAVEGACIÓN: (Reto de UT2-P1 enunciado original...)
                AppNavigation()
            }
        }
    }
}


//Esta función inserta Spacers del tamaño indicado
@Composable
fun InsertSpacer(n: Int) {
    Spacer(modifier = Modifier.size(n.dp))
}

//ORIENTACIÓN
@Composable
fun Orientacion() {
    val configuration = LocalConfiguration.current //variable que indica la orientación actual

    when (configuration.orientation) {
        Configuration.ORIENTATION_LANDSCAPE -> {
            landscape = true
            pesoMenor = 1f
            pesoMayor = 3f
            cardHeight = 200
        }
        else -> {
            landscape = false
            pesoMenor = 1f
            pesoMayor = 2f
            cardHeight = 100
        }
    }
}

//NAVEGACIÓN ENTRE PANTALLAS:
//Implementación de navegación entre pantallas añadiendo la siguiente dependencia:
//implementation("androidx.navigation:navigation-compose:2.8.0")
@Preview
@Composable
fun AppNavigation() {
    val navController = rememberNavController()
    NavHost(navController = navController, startDestination = "1-playJuegosPPG") {
        composable("1-playJuegosPPG") {
            PlayJuegosPPG(navController)
        }
        composable("2-NewPlayer") {
            NewPlayer(navController)
        }
        composable("3-Preferences") {
            Preferences(navController)
        }
        composable("4-Play") {
            Play(navController)
        }
        composable("5-Users") {
            user(navController)
        }
    }
}