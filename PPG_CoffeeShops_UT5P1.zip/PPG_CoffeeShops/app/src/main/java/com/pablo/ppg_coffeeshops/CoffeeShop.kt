package com.pablo.ppg_coffeeshops

import androidx.annotation.DrawableRes

data class CoffeeShop (
    val name: String,
    @DrawableRes val imgId: Int,
    val address: String,
    var rating: Double = 3.0
)