package com.pablo.ppg_coffeeshops

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddLocation
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Coffee
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Card
import androidx.compose.material3.DrawerState
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.pablo.ppg_coffeeshops.ui.theme.caveatFont
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

//Función que devuelve una lista de coffeShops predefinidos:
fun getCoffeeShops(): List<CoffeeShop> {
    return listOf(
        CoffeeShop("Café Albores", R.drawable.cafe1, "C/ Albor, 23"),
        CoffeeShop("Café Esmorzaret", R.drawable.cafe2, "C/ Almuerzo, 10"),
        CoffeeShop("Café Manzanar", R.drawable.cafe3, "C/ Manzanos, 8"),
        CoffeeShop("Café Felino", R.drawable.cafe4, "C/ Lince, 7"),
        CoffeeShop("Café Centro", R.drawable.cafe5, "C/ Centrada, 91"),
        CoffeeShop("Café Vespertino", R.drawable.cafe6, "C/ Tardores, 18"),
        CoffeeShop("Café Noctámbulo", R.drawable.cafe7, "C/ Oscura, 25"),
        CoffeeShop("Café Terreta", R.drawable.cafe8, "C/ Valencia, 5"),
    )
}


@Composable
fun coffeeShopsMenu(navController: NavController) {
    //Obtenemos nuestra lista de coffeeShops
    val coffeeShops = getCoffeeShops()

    //Creamos las variables de estado del ModalDrawer (UT5-P1-Ej4):
    val myDrawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val corutina = rememberCoroutineScope()

    //Añadimos un menú lateral (UT5-P1-Ej4):
    //Como no se indica lo contrario, se superpone el menú lateral a las AppBar de Scaffold
    MyModalDrawer(drawerState = myDrawerState, corutina,
        contenido = {
            //Para introducir la TopAppBar utilizamos el layout Scaffold (típico de la UI de android):
            Scaffold(
                //Definimos nuestra topBar
                topBar = {
                    MyTopAppBar(myDrawerState)//Definimos los parámetros de nuestra TopAppBar en una funcion aparte
                },
                content = { padding ->
                    //Al utilizar Scaffold, el contenido central de la pantalla va entre estas llaves,
                    //y le pasamos un padding para que no solape el contenido con la propia topBar
                    //Implementamos LazyColumn de nuestros coffeShops
                    LazyColumn(
                        modifier = Modifier.padding(padding),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        items(coffeeShops) { cafe ->
                            itemCoffeeShop(coffeeShop = cafe, navController)
                        }
                    }
                }
            )
        }
    )
}


//Función que crea un elemento Card por CoffeeShop
@Composable
fun itemCoffeeShop(coffeeShop: CoffeeShop, navController: NavController) {
    val starsRating = rememberSaveable { mutableStateOf(0) }
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
            .clickable { navController.navigate("2-CoffeeShopReview/${coffeeShop.name}") }
    ) {
        Column(modifier = Modifier.padding(8.dp)) {
            Image(
                painter = painterResource(id = coffeeShop.imgId),
                contentDescription = null,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp)
                    //.height(400.dp)
                    .clip(RoundedCornerShape(8.dp)),
                contentScale = ContentScale.Crop
            )
            Text(
                text = coffeeShop.name,
                style = MaterialTheme.typography.displaySmall,
                modifier = Modifier.padding(8.dp),
                fontFamily = caveatFont
            )
            Text(
                text = coffeeShop.address,
                style = MaterialTheme.typography.bodyLarge,
                modifier = Modifier.padding(8.dp)
            )
            //Star Rating (5 estrellas)
            Row(
                horizontalArrangement = Arrangement.Start,
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .padding(8.dp)
                    .fillMaxWidth(0.75f)
            ) {
                repeat(5) { index ->
                    IconButton(
                        onClick = { starsRating.value = index + 1 }
                    ) {
                        Icon(
                            imageVector = Icons.Default.Star,
                            contentDescription = "Star icon",
                            tint = if (index < starsRating.value) Color.Black else Color.Gray,
                            modifier = Modifier.size(40.dp)
                        )
                    }
                }
            }
            Row {
                HorizontalDivider(
                    color = Color.DarkGray,
                    thickness = 1.dp,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp)
                )
            }
            TextButton(onClick = { /* Sin funcionalidad */ }) {
                Text(
                    text = "Reservar",
                    fontSize = medTextSize.sp
                )
            }
        }
    }
}


//Función que implementa un menú lateral (ModalDrawer)
//entre las AppBar y el contenido de Scaffold
@Composable
fun MyModalDrawer(
    drawerState: DrawerState, corutina: CoroutineScope,
    contenido: @Composable () -> Unit
) {
    //Definimos el ModalDrawer
    ModalNavigationDrawer(
        drawerState = drawerState,
        gesturesEnabled = true, //Habilitamos apertura por gesto y cierre al clickar fuera
        drawerContent = {
            ModalDrawerSheet(drawerTonalElevation = 100.dp,
                modifier = Modifier.clickable {
                    //Lo dejamos en blanco para que no cierre el menú al clicar dentro del propio menú
                }) {
                //Primera opción del menú
                NavigationDrawerItem(
                    label = { Text("Ubicación") },
                    selected = false,
                    modifier = Modifier.padding(8.dp),
                    onClick = { },
                    icon = {
                        Icon(
                            Icons.Filled.AddLocation,
                            contentDescription = "Icono ubicación"
                        )
                    }
                )
                //Segunda opción del menú
                NavigationDrawerItem(
                    label = { Text("Info") },
                    selected = false,
                    modifier = Modifier.padding(8.dp),
                    onClick = { },
                    icon = { Icon(Icons.Filled.Info, contentDescription = "Icono info") }
                )
                //Tercera opción del menú
                NavigationDrawerItem(
                    label = { Text("Reservar") },
                    selected = false,
                    modifier = Modifier.padding(8.dp),
                    onClick = { },
                    icon = { Icon(Icons.Filled.Coffee, contentDescription = "Icono café") }
                )
                //Cuarta opción del menú
                NavigationDrawerItem(
                    label = { Text("Cerrar") },
                    selected = false,
                    modifier = Modifier.padding(8.dp),
                    onClick = {
                        corutina.launch {
                            drawerState.apply {
                                if (isClosed) open() else close()
                            }
                        }
                    },
                    icon = { Icon(Icons.Filled.Close, contentDescription = "Icono cerrar") }
                )
            }
        }
    ) {
        //En contenido se implementa el layout de esta pantalla, incluyendo las AppBars,
        //el código del mismo se define en la llamada a esta funcion MyModalDrawer
        contenido()
    }
}
