package com.pablo.ppg_coffeeshops


import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.staggeredgrid.LazyVerticalStaggeredGrid
import androidx.compose.foundation.lazy.staggeredgrid.StaggeredGridCells
import androidx.compose.foundation.lazy.staggeredgrid.items
import androidx.compose.foundation.lazy.staggeredgrid.rememberLazyStaggeredGridState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pablo.ppg_coffeeshops.ui.theme.caveatFont


//Pantalla que muestra los comentarios de cada CoffeeShop
@Composable
fun coffeeShopReview(coffeeShopName: String) {
    //ALmacenamos la lista de comentarios
    val reviews = getReviews()


    //variable de estado de la lista:
    val lazyGridState = rememberLazyStaggeredGridState()


    //Variables para trackear la posición anterior y determinar dirección del scroll
    var previousIndex by remember { mutableStateOf(0) }
    var previousScrollOffset by remember { mutableStateOf(0) }

    //Variable para controlar si estamos haciendo scroll hacia arriba
    var isScrollingUp by remember { mutableStateOf(false) }

    //Listener de scroll. LaunchedEffect lanza una corrutina cuando se da o cambia alguno de sus parámetros,
    //en este caso, se activará sólo cuando se hace scroll y calcula si el scroll es hacia arriba o no:
    LaunchedEffect(
        lazyGridState.firstVisibleItemIndex,
        lazyGridState.firstVisibleItemScrollOffset
    ) {
        val currentIndex = lazyGridState.firstVisibleItemIndex
        val currentScrollOffset = lazyGridState.firstVisibleItemScrollOffset

        //Detecta si el usuario está haciendo scroll hacia arriba
        isScrollingUp = if (currentIndex == previousIndex) {
            //Mismo índice, verificar el desplazamiento vertical
            currentScrollOffset < previousScrollOffset
        } else {
            //Diferente índice, verificar el índice
            currentIndex < previousIndex
        }

        // Actualizar posición anterior
        previousIndex = currentIndex
        previousScrollOffset = currentScrollOffset
    }

//RETO UT4-P2-Ej2
    //Variable que controle mostrar un botón sólo cuando se llegue al final de los comentarios
    var scrollBottom by remember { mutableStateOf(false) }

    // Monitorizamos el scroll para ver si hemos llegado al final
    LaunchedEffect(lazyGridState.firstVisibleItemIndex) {
        //snapshotFlow nos da información sobre el estado puntual del lazyGrid
        snapshotFlow { lazyGridState.layoutInfo }
            //Almacenamos información sobre layoutInfo, que nos permite acceder a la cantidad de
            //elementos visibles de la lazyGrid:
            .collect { layoutInfo ->
                //Guardamos el ultimo elemento actualmente visible:
                val lastVisibleItemIndex = layoutInfo.visibleItemsInfo.lastOrNull()?.index
                //guardamos el total de los elementos de la lazyGrid:
                val totalItems = layoutInfo.totalItemsCount
                //Si el último elemento visible no es nulo y es igual al último de la lazyGrid,
                //podemos asumir que estamos al final de la lista (o al menos ya se ve el último elemento):
                scrollBottom =
                    (lastVisibleItemIndex != null && lastVisibleItemIndex == totalItems - 1)
            }
    }


    //Variables que controlan la barra de búsqueda:
    var searchText by rememberSaveable { mutableStateOf("") }

    //Variable de estado que filtra los comentarios según searchText
    val filteredReviews = reviews.filter {
        it.comentario.contains(searchText.trim(), ignoreCase = true)
    }


    //Creamos las variables de estado del ModalDrawer (UT5-P1-Ej4):
    val myDrawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val corutina = rememberCoroutineScope()

    //Añadimos un menú lateral (UT5-P1-Ej4):
    //Como no se indica lo contrario, se superpone el menú lateral a las AppBar de Scaffold
    MyModalDrawer(
        drawerState = myDrawerState, corutina,
        contenido = {
            //Para introducir la TopAppBar utilizamos el layout Scaffold (típico de la UI de android):
            Scaffold(
                //Definimos nuestra topBar
                topBar = {
                    MyTopAppBar(myDrawerState)//Definimos los parámetros de nuestra TopAppBar en una funcion aparte
                },
                content = { padding ->
                    //Al utilizar Scaffold, el contenido central de la pantalla va entre estas llaves,
                    //y le pasamos un padding para que no solape el contenido con la propia topBar
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(padding),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Top
                    ) {
                        //Nombre del CoffeeShop
                        Text(
                            text = coffeeShopName,
                            style = MaterialTheme.typography.displayLarge,
                            modifier = Modifier.padding(minSpacing.dp),
                            fontFamily = caveatFont
                        )

                        //RETO UT4-P2-Ej2
                        //Barra de búsqueda:
                        Box(
                            modifier = Modifier
                                .fillMaxWidth(0.8f)
                                .background(
                                    color = MaterialTheme.colorScheme.secondary,
                                    shape = RoundedCornerShape(30.dp)
                                )
                        ) {
                            TextField(
                                value = searchText,
                                onValueChange = { searchText = it },
                                placeholder = { Text("Buscar...", fontSize = 14.sp) },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(30.dp),
                                trailingIcon = {
                                    IconButton(onClick = {}) {
                                        Icon(
                                            imageVector = Icons.Default.Search,
                                            contentDescription = "Buscar"
                                        )
                                    }
                                }
                            )
                        }

                        InsertSpacer(minSpacing)

                        //LazyVerticalStaggeredView con las reviews
                        LazyVerticalStaggeredGrid(
                            state = lazyGridState,//IMPORTANTE DEFINIR EL MODIFICADOR STATE O NO FUNCIONARA EL CONTROL DE DESPLAZAMIENTO
                            columns = StaggeredGridCells.Fixed(2),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.weight(1f),
                            verticalItemSpacing = 12.dp,
                        ) {
                            //items(reviews){ //En lugar de pasar todas las reviews,
                            //Reto UT4-P2-Ej2:
                            items(filteredReviews) { //Pasamos sólo aquellas que contienen el término de la barra de búsqueda
                                itemReview(it)
                            }
                        }


                        //derivedStateOf significa que esta variable de estado sólo se Compondrá cuando cambie
                        //la variable de la que depende (la interior)
                        //showButton será true sólo cuando el scroll esté arriba del t0do
                        //el primer elemento visible es el 0 y el offset del primer elemento es tambiémn 0:
                        val showButton by remember {
                            derivedStateOf {
                                lazyGridState.firstVisibleItemIndex == 0 &&
                                        lazyGridState.firstVisibleItemScrollOffset == 0
                            }
                        }

                        //El botón sólo se muestra si estamos haciendo scroll hacia arriba o estamos arriba del tod0:
                        if (isScrollingUp || showButton) {
                            Button(
                                modifier = Modifier
                                    .align(Alignment.CenterHorizontally)
                                    .padding(16.dp)
                                    .fillMaxWidth(0.6f),
                                onClick = {}
                            ) {
                                Text(text = "Add new comment")
                            }
                        }


                        //Reto UT4-P2-Ej2:
                        //El botón sólo se muestra si estamos abajo del tod0 y además no estamos haciendo scrollUp:
                        if (scrollBottom && !isScrollingUp && !showButton) {
                            Button(
                                modifier = Modifier
                                    .align(Alignment.CenterHorizontally)
                                    .padding(16.dp)
                                    .fillMaxWidth(0.6f),
                                onClick = {}
                            ) {
                                Text(text = "Bottom reached")
                            }
                        }
                    }
                }
            )
        }
    )
}


@Composable
fun itemReview(review: Review) {
    Card(
        modifier = Modifier
            .fillMaxHeight(),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Text(
            text = review.comentario,
            modifier = Modifier
                .align(Alignment.CenterHorizontally)
                .padding(mediumSpacing.dp),
            fontSize = 12.sp
        )
    }
}
