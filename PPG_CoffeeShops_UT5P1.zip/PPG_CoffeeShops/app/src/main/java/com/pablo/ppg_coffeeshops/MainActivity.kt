package com.pablo.ppg_coffeeshops

import android.content.res.Configuration
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.DrawerState
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.pablo.ppg_coffeeshops.ui.theme.PPG_CoffeeShopsTheme
import kotlinx.coroutines.launch

//Variables para controlar orientación
var landscape = false
var pesoMenor = 0f
var pesoMayor = 0f

//Definimos algunas variables para un diseño consistente
val minSpacing = 4
val mediumSpacing = 16
val medTextSize = 24


class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            PPG_CoffeeShopsTheme {
                AppNavigation()
            }
        }
    }
}


//Esta función inserta Spacers del tamaño indicado
@Composable
fun InsertSpacer(n: Int) {
    Spacer(modifier = Modifier.size(n.dp))
}

//ORIENTACIÓN
@Composable
fun Orientacion() {
    val configuration = LocalConfiguration.current //variable que indica la orientación actual

    when (configuration.orientation) {
        Configuration.ORIENTATION_LANDSCAPE -> {
            landscape = true
            pesoMenor = 1f
            pesoMayor = 3f
        }
        else -> {
            landscape = false
            pesoMenor = 1f
            pesoMayor = 2f
        }
    }
}

//NAVEGACIÓN ENTRE PANTALLAS:
//Implementación de navegación entre pantallas añadiendo la siguiente dependencia:
//implementation("androidx.navigation:navigation-compose:2.8.0")
@Preview
@Composable
fun AppNavigation() {
    val navController = rememberNavController()
    NavHost(navController = navController, startDestination = "1-CoffeeShopsMenu") {
        composable("1-CoffeeShopsMenu") {
            coffeeShopsMenu(navController)
        }
        composable(
            route = "2-CoffeeShopReview/{coffeeShopName}") { backStackEntry ->
            val coffeeShopName = backStackEntry.arguments?.getString("coffeeShopName")
            coffeeShopReview(coffeeShopName!!)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MyTopAppBar(drawerState: DrawerState) {
    //Estado para controlar si el menú está desplegado o no
    var menuExpanded by remember { mutableStateOf(false) }

    //Estado de alcance para manejar el menú lateral (UT5-P1-Ej4)
    var corutina = rememberCoroutineScope()

    TopAppBar(
        //Título de la Topbar
        title = { Text(text="Coffee Shops by PPG", color = Color.White) },
        //Icono de navegación, a la izquierda
        navigationIcon = {
            IconButton(onClick = {
                corutina.launch {
                    drawerState.apply {
                        if (isClosed) open() else close()
                    }
                }
            }) {
                Icon(
                    imageVector = Icons.Default.Menu,
                    contentDescription = "Icono Menú",
                    tint = Color.White
                )
            }
        },
        //Iconos de acción, a la derecha
        actions = {
            //Botón de overflow
            //Al hacer clic desplegamos el menú
            IconButton(onClick = { menuExpanded = true }) {
                Icon(
                    imageVector = Icons.Default.MoreVert,
                    contentDescription = "Más opciones",
                    tint = Color.White
                )
            }
            //Menú desplegable
            DropdownMenu(
                expanded = menuExpanded,
                onDismissRequest = { menuExpanded = false }
            ) {
                //Primera opción del menú
                DropdownMenuItem(
                    text = { Text("Settings") },
                    onClick = {
                        menuExpanded = false
                        println("Opción 1 seleccionada")
                    },
                    leadingIcon = {
                        Icon(Icons.Default.Settings, contentDescription = "Configuración")
                    }
                )
                //Segunda opción del menú
                DropdownMenuItem(
                    text = { Text("About") },
                    onClick = {
                        menuExpanded = false
                        println("Opción 2 de seleccionada")
                    },
                    leadingIcon = {
                        Icon(Icons.Default.Info, contentDescription = "Acerca de")
                    }
                )
            }
        },
        //Colores
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = MaterialTheme.colorScheme.primary,
            titleContentColor = Color.White,
            actionIconContentColor = Color.White
        )
    )
}