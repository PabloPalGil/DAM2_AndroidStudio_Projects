package com.pablo.ppg_coffeeshops

data class Review (var comentario: String)


fun getReviews(): List<Review> {
    return listOf(
        Review("Servicio algo flojo, aún así lo recomiendo"),
        Review("Céntrica y acogedora. Volveremos seguro"),
        Review("La ambientacion muy buena, pero en la planta de arriba un poco escasa."),
        Review("La comida estaba deliciosa y bastante bien de precio, mucha variedad de platos"),
        Review("El personal muy amable, nos permitieron ver todo el establecimiento."),
        Review("Muy bueno"),
        Review("Excelente. Destacable la extensa carta de cafés"),
        Review("Buen ambiente y buen servicio. Lo recomiendo."),
        Review("En días festivos demasiado tiempo de espera. Los camareros/as no dan abasto. No lo recomiendo. No volveré"),
        Review("Repetiremos. Gran selección de tartas y cafés."),
        Review("Todo lo que he probado en la cafetería está riquísimo, dulce o salado."),
        Review("La vajilla muy bonita todo de diseño que en el entorno del bar queda ideal."),
        Review("Puntos negativos: el servicio es muy lento y los precios son un poco elevados."),
        Review("Muy bueno"),
        Review("Excelente. Destacable la extensa carta de cafés"),
        Review("Buen ambiente y buen servicio. Lo recomiendo."),
        Review("En días festivos demasiado tiempo de espera. Los camareros/as no dan abasto. No lo recomiendo. No volveré"),
        Review("Repetiremos. Gran selección de tartas y cafés."),
        Review("Todo lo que he probado en la cafetería está riquísimo, dulce o salado."),
        Review("Repetiremos. Gran selección de tartas y cafés."),
        Review("Todo lo que he probado en la cafetería está riquísimo, dulce o salado."),
        Review("La vajilla muy bonita todo de diseño que en el entorno del bar queda ideal."),
        Review("Puntos negativos: el servicio es muy lento y los precios son un poco elevados.")
    )
}